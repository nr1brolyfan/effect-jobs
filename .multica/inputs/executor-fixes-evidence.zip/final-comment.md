Naprawiłem wyłącznie accepted **R1/R2**. Backoff zachowuje 1000 ms mimo overdue due/recovery/generation; MoreWork=100 ms i activation=400 ms pozostają poprawne. Provider zachowuje cały Cause: Fail(ResponseLost), dokładny rollback Die oraz interruption; rzeczywisty handler zachowuje te reasons. Commit: `fix(playground): preserve executor backoff and provider causes`.

- base: `219cf989834158d221864b9f69206b8b82ba5b36`
- head: `6f38cb8576cac347e9163e639267d1b154ab777e`
- tree: `3699acd3f62c4ea8507b2eee24f27ea19e58cf37`
- branch: `agent/effect-jobs-implementor/upve-1870`

Zachowałem runtime commit `c3bbce0`, zawierający wyłącznie wcześniejsze dowody; jego kod produktu jest identyczny z frozen `b9717cc`. PASS: oryginalne wejścia reprodukcji z poprawionymi oracles i kontrole na **Node 24.15.0 / Bun 1.4.2**; sześć dotkniętych grup **PG 16.15 / Node / Bun / lokalny workerd 1.20261006.1**; strict packed types, worker bundle, typy/build aplikacji, focused lint/format. Ledger/retry/unknown/dead/isolate/recovery i global retirement/resume PASS; sesje po Scope: 0. Zweryfikowano **90 końcowych wejść**, bez rozbieżności. Niezmienione reset/quota/authority receipts zachowane; pełnej macierzy nie powtarzałem.

Pierwszy pomiar etapu: **20:57:41 UTC**; bramki PG **21:01:13–32**, gotowość handoffu **21:03:11**, deadline **22:18:50 UTC**. Każda ciężka bramka <10 min. Przed provision potwierdzono brak pięciu dawnych exact IDs; jedyny nowy kontener usunięto po exact ID, prywatny config i trzy własne consumery usunięte. Załącznik zawiera patch, końcowe źródła/artefakty i hashe, commands/receipts, docs-read, oryginalny triage oraz zachowane błędy setupu/oracle z diagnozą.

Bez kolejnego review/triage, push/PR/merge/deploy ani zmian biblioteki/shared manifestów/registrarów/migracji. Gotowe do odbioru; UPVE-1872 pozostaje nieaktywne. Dotychczasowy handoff dodatków integracyjnych pozostaje aktualny. Hosted CF, automatyczne alarm callbacks, Alchemy, crash/network/CPU, browser integration i terminal cleanup: **NotTested**. Odziedziczone global lint warnings pozostają; nie deklaruję pełnego push-preflight PASS. Reset zachowuje stare jobs/quota; retry/redrive/cancel=false.
