var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/execution/Executor.ts
var Executor_exports = {};
__export(Executor_exports, {
  ExecutionDeadline: () => ExecutionDeadline,
  ExecutionHints: () => ExecutionHints,
  consumers: () => consumers,
  generate: () => generate,
  limits: () => limits3,
  queueNames: () => queueNames,
  run: () => run,
  snapshot: () => snapshot,
  workerLayerNoDeps: () => workerLayerNoDeps
});
import { Clock as Clock3, Context as Context10, Effect as Effect21, Layer as Layer9, Schema as Schema23 } from "effect";
import { SqlClient as SqlClient2 } from "effect/sql/SqlClient";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobConsumer.ts
import { Data, Effect, Schema } from "effect";
var ConsumerOptions = Schema.Struct({
  /** Shared per-worker queue permits, acquired before claim; integer 1–64. */
  localConcurrency: Schema.Int.pipe(
    Schema.check(Schema.isBetween({ minimum: 1, maximum: 64 }))
  ),
  /** Maximum started claims in one finite drain; integer 1–10,000. */
  claimLimitPerRun: Schema.Int.pipe(
    Schema.check(Schema.isBetween({ minimum: 1, maximum: 1e4 }))
  ),
  /** Maximum rows considered for expiry recovery per drain; integer 1–10,000. */
  recoveryLimitPerRun: Schema.Int.pipe(
    Schema.check(Schema.isBetween({ minimum: 1, maximum: 1e4 }))
  )
});
var InvalidJobConsumer = class extends Data.TaggedError("InvalidJobConsumer") {
};
var DuplicateJobConsumer = class extends Data.TaggedError("DuplicateJobConsumer") {
  get message() {
    return `Duplicate consumer for ${this.queue}; configure one consumer per logical queue`;
  }
};
var make = (queue, options) => Schema.decodeEffect(ConsumerOptions)(options, { onExcessProperty: "error" }).pipe(
  Effect.map((decoded) => Object.freeze({ queue, ...decoded })),
  Effect.mapError(() => new InvalidJobConsumer({ reason: "invalid-options" }))
);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Drain.ts
import { Effect as Effect6, Fiber, Semaphore as Semaphore2 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobWorker.ts
import { Cause as Cause3, Context as Context2, Effect as Effect5, Layer as Layer2, Schema as Schema9, Semaphore } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobIdentity.ts
import { Data as Data2, Schema as Schema2 } from "effect";
var nameFormat = "^[a-z][a-z0-9.-]*$";
var namePattern = /^[a-z][a-z0-9.-]*$/u;
var name = (maximum) => Schema2.String.pipe(
  Schema2.check(
    Schema2.isMinLength(1),
    Schema2.isMaxLength(maximum),
    Schema2.isPattern(namePattern)
  )
);
var QueueName = name(64);
var JobKind = name(128);
var OperationName = name(128);
var SlotName = name(128);
var JobVersion = Schema2.Int.pipe(
  Schema2.check(Schema2.isBetween({ minimum: 1, maximum: 32767 }))
);
var CatalogIdentity = Schema2.Struct({
  queue: QueueName,
  kind: JobKind,
  version: JobVersion
});
var utf8 = new TextEncoder();
var validScalars = (value) => {
  for (const scalar of value) {
    const code = scalar.codePointAt(0);
    if (code >= 55296 && code <= 57343) {
      return false;
    }
  }
  return true;
};
var InvalidOperationId = class extends Data2.TaggedError("InvalidOperationId") {
};
var validateOperationId = (value) => {
  if (!validScalars(value)) {
    throw new InvalidOperationId({ rule: "unicode-scalars" });
  }
  if (value.includes("\0")) {
    throw new InvalidOperationId({ rule: "no-nul" });
  }
  const byteLength = utf8.encode(value).byteLength;
  if (byteLength < 1 || byteLength > 256) {
    throw new InvalidOperationId({ rule: "utf8-length", byteLength });
  }
};
var OperationId = Schema2.String.pipe(
  Schema2.check(
    Schema2.makeFilter((value) => {
      const length = utf8.encode(value).byteLength;
      return validScalars(value) && !value.includes("\0") && length >= 1 && length <= 256;
    })
  )
);
var ProducerIdentity = Schema2.Struct({
  operation: OperationName,
  operationId: OperationId,
  slot: SlotName
});
var JobDeclarationError = class extends Data2.TaggedError("JobDeclarationError") {
};
var validateProducerDeclaration = (input) => {
  const expected = `1\u2013128 ASCII characters matching ${nameFormat}`;
  if (!Schema2.is(OperationName)(input.operation)) {
    throw new JobDeclarationError({
      field: "operation",
      value: input.operation,
      expected
    });
  }
  if (input.slots.length === 0) {
    throw new JobDeclarationError({
      field: "slots",
      expected: "at least one unique slot"
    });
  }
  const seen = /* @__PURE__ */ new Set();
  input.slots.forEach((slot, index) => {
    if (!Schema2.is(SlotName)(slot)) {
      throw new JobDeclarationError({ field: `slots[${index}]`, value: slot, expected });
    }
    if (seen.has(slot)) {
      throw new JobDeclarationError({
        field: `slots[${index}]`,
        value: slot,
        expected: "unique declared slot"
      });
    }
    seen.add(slot);
  });
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobPolicy.ts
import { Data as Data3, Duration, Schema as Schema3 } from "effect";
var maximumMillis = 253402300799999;
var PositiveMillis = Schema3.Int.pipe(
  Schema3.check(Schema3.isBetween({ minimum: 1, maximum: maximumMillis }))
);
var EpochMillis = PositiveMillis;
var JobRetention = Schema3.Union([
  Schema3.TaggedStruct("Forever", {}),
  Schema3.TaggedStruct("Duration", { millis: PositiveMillis })
]);
var FixedDelayV1 = Schema3.TaggedStruct("FixedDelayV1", {
  delayMillis: PositiveMillis
});
var PolicyStruct = Schema3.Struct({
  leaseDurationMillis: PositiveMillis,
  attemptTimeoutMillis: PositiveMillis,
  maxAttempts: Schema3.Int.pipe(
    Schema3.check(Schema3.isBetween({ minimum: 1, maximum: 100 }))
  ),
  maxStalledCount: Schema3.Int.pipe(
    Schema3.check(Schema3.isBetween({ minimum: 0, maximum: 100 }))
  ),
  retrySchedule: FixedDelayV1,
  completedRetention: JobRetention,
  deadRetention: JobRetention
});
var PersistedJobPolicy = PolicyStruct.pipe(
  Schema3.check(Schema3.makeFilter((p) => p.attemptTimeoutMillis < p.leaseDurationMillis))
);
var JobPolicyConfigurationError = class extends Data3.TaggedError(
  "JobPolicyConfigurationError"
) {
};
var millis = (value, field) => {
  const n = Duration.match(value, {
    onMillis: (n2) => n2,
    onNanos: (nanos) => nanos % 1000000n === 0n && nanos > 0n && nanos <= BigInt(maximumMillis) * 1000000n ? Number(nanos / 1000000n) : NaN,
    onInfinity: () => Infinity,
    onNegativeInfinity: () => -Infinity
  });
  if (!Schema3.is(PositiveMillis)(n)) {
    throw new JobPolicyConfigurationError({
      field,
      expected: `finite integer milliseconds in 1\u2013${maximumMillis}`
    });
  }
  return n;
};
var retention = (value, field) => Object.freeze(
  !Duration.isFinite(value) && Duration.toMillis(value) === Infinity ? { _tag: "Forever" } : { _tag: "Duration", millis: millis(value, field) }
);
var make2 = (options = {}) => {
  const leaseDurationMillis = millis(
    options.leaseDuration ?? Duration.seconds(90),
    "leaseDuration"
  );
  const attemptTimeoutMillis = millis(
    options.attemptTimeout ?? Duration.seconds(30),
    "attemptTimeout"
  );
  if (attemptTimeoutMillis >= leaseDurationMillis) {
    throw new JobPolicyConfigurationError({
      field: "attemptTimeout",
      expected: "strictly less than leaseDuration"
    });
  }
  const maxAttempts = options.maxAttempts ?? 3;
  const maxStalledCount = options.maxStalledCount ?? 1;
  if (!Schema3.is(PolicyStruct.fields.maxAttempts)(maxAttempts)) {
    throw new JobPolicyConfigurationError({
      field: "maxAttempts",
      expected: "integer in 1\u2013100"
    });
  }
  if (!Schema3.is(PolicyStruct.fields.maxStalledCount)(maxStalledCount)) {
    throw new JobPolicyConfigurationError({
      field: "maxStalledCount",
      expected: "integer in 0\u2013100"
    });
  }
  return Object.freeze({
    leaseDurationMillis,
    attemptTimeoutMillis,
    maxAttempts,
    maxStalledCount,
    retrySchedule: Object.freeze({
      _tag: "FixedDelayV1",
      delayMillis: millis(options.retryDelay ?? Duration.seconds(5), "retryDelay")
    }),
    completedRetention: retention(
      options.completedRetention ?? Duration.days(90),
      "completedRetention"
    ),
    deadRetention: retention(options.deadRetention ?? Duration.infinity, "deadRetention")
  });
};
var defaultPolicy = make2();

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobRegistry.ts
import { Context, Data as Data4, Effect as Effect2, Layer } from "effect";
var DuplicateJobHandler = class extends Data4.TaggedError(
  "DuplicateJobHandler"
) {
  get message() {
    return `Handler already installed for ${this.queue}/${this.kind}@${this.version}; install one handler per catalog entry`;
  }
};
var DuplicateJobCatalogEntry = class extends Data4.TaggedError(
  "DuplicateJobCatalogEntry"
) {
  get message() {
    return `Duplicate catalog entry ${this.queue}/${this.kind}@${this.version}; use a unique queue/kind/version`;
  }
};
var JobRegistry = class extends Context.Service()(
  "effect-jobs/JobRegistry"
) {
};
var key = (catalog) => `${catalog.queue}\0${catalog.kind}\0${catalog.version}`;
var layer = Layer.sync(JobRegistry, () => {
  const handlers = /* @__PURE__ */ new Map();
  return JobRegistry.of({
    install: (handler) => Effect2.suspend(() => {
      const catalogKey = key(handler.catalog);
      if (handlers.has(catalogKey)) {
        return Effect2.fail(new DuplicateJobHandler(handler.catalog));
      }
      const catalog = Object.freeze({
        queue: handler.catalog.queue,
        kind: handler.catalog.kind,
        version: handler.catalog.version
      });
      handlers.set(catalogKey, Object.freeze({ catalog, execute: handler.execute }));
      return Effect2.void;
    }),
    find: (catalog) => handlers.get(key(catalog))
  });
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobTelemetry.ts
import { Cause, Clock, Effect as Effect3, Exit, Metric } from "effect";
var successOutcome = (value) => {
  if (typeof value === "object" && value !== null && "_tag" in value) {
    if (value._tag === "Unknown" || value._tag === "Unresolved") {
      return "unknown";
    }
    if (value._tag === "Backoff") {
      return "failure";
    }
  }
  return "success";
};
var total = Metric.counter("effect_jobs_operation_total", { incremental: true });
var duration = Metric.histogram("effect_jobs_operation_duration_millis", {
  boundaries: [1, 10, 100, 1e3, 1e4, 6e4]
});
var observe = (operation, phase) => (effect) => Effect3.uninterruptibleMask(
  (restore) => Effect3.gen(function* () {
    let exit;
    yield* Effect3.gen(function* () {
      const started = yield* Clock.currentTimeMillis;
      exit = yield* Effect3.exit(restore(effect));
      const ended = yield* Clock.currentTimeMillis;
      const reasons = Exit.isFailure(exit) ? exit.cause.reasons : [];
      const kinds = new Set(
        reasons.map(
          (reason2) => Cause.isFailReason(reason2) ? "failure" : Cause.isDieReason(reason2) ? "defect" : "interrupted"
        )
      );
      const [reason] = reasons;
      const outcome = Exit.isSuccess(exit) ? successOutcome(exit.value) : reasons.length === 1 && reason !== void 0 && Cause.isFailReason(reason) && reason.error instanceof Cause.TimeoutError ? "timeout" : kinds.size === 1 && kinds.has("interrupted") ? "interrupted" : "failure";
      const fields = {
        "jobs.operation": operation,
        "jobs.phase": phase,
        "jobs.outcome": outcome,
        ...reasons.length === 0 ? {} : {
          "jobs.cause_kind": kinds.size > 1 ? "mixed" : [...kinds][0],
          "jobs.reason_count_bucket": reasons.length === 1 ? "1" : reasons.length === 2 ? "2" : "3+"
        }
      };
      yield* Effect3.annotateCurrentSpan(fields);
      yield* Metric.update(Metric.withAttributes(total, fields), 1);
      yield* Metric.update(
        Metric.withAttributes(duration, fields),
        Math.max(0, ended - started)
      );
      yield* Effect3.logInfo("effect-jobs operation completed", fields);
    }).pipe(Effect3.withSpan(`effect-jobs.${operation}`));
    return exit;
  })
).pipe(Effect3.flatMap((exit) => exit));

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/FailureCode.ts
import { Data as Data5, Result, Schema as Schema4 } from "effect";
var FailureCode = Schema4.String.pipe(
  Schema4.check(
    Schema4.isMinLength(1),
    Schema4.isMaxLength(128),
    Schema4.isPattern(/^[a-z0-9][a-z0-9_-]*$(?![\s\S])/u)
  ),
  Schema4.brand("effect-jobs/FailureCode")
);
var InvalidFailureCode = class extends Data5.TaggedError("InvalidFailureCode") {
  get message() {
    return `Invalid failure code entry ${this.entry}: expected ${this.expected}`;
  }
};
var parse = (value) => Schema4.decodeResult(FailureCode)(value).pipe(
  Result.mapError(
    () => new InvalidFailureCode({
      entry: "dynamic",
      expected: "1\u2013128 characters matching ^[a-z0-9][a-z0-9_-]*$"
    })
  )
);
var define = (codes2) => {
  const validated = Object.fromEntries(
    Object.entries(codes2).map(([entry, value]) => {
      const result = parse(value);
      if (Result.isFailure(result)) {
        throw new InvalidFailureCode({ entry, expected: result.failure.expected });
      }
      return [entry, result.success];
    })
  );
  return Object.freeze(validated);
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobLifecycle.ts
import { Data as Data7, Result as Result2, Schema as Schema7 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobId.ts
import { Schema as Schema5 } from "effect";
var JobId = Schema5.String.pipe(
  Schema5.check(Schema5.isMinLength(1)),
  Schema5.brand("effect-jobs/JobId")
);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobFailure.ts
import { Data as Data6, Schema as Schema6 } from "effect";
var JobFailure = Schema6.Union([
  Schema6.TaggedStruct("Retry", {
    code: FailureCode,
    notAfter: Schema6.optional(EpochMillis)
  }),
  Schema6.TaggedStruct("Dead", { code: FailureCode }),
  Schema6.TaggedStruct("Isolate", { code: FailureCode }),
  Schema6.TaggedStruct("OutcomeUnknown", { code: FailureCode })
]);
var failures = Data6.taggedEnum();
var InvalidJobFailure = class extends Data6.TaggedError("InvalidJobFailure") {
};
var checked = (value) => {
  if (value._tag === "Retry" && value.notAfter !== void 0 && !Schema6.is(EpochMillis)(value.notAfter)) {
    throw new InvalidJobFailure({ field: "notAfter" });
  }
  return Object.freeze(value);
};
var JobFailures = Object.freeze({
  /** Persisted fixed-delay retry within attempt bounds; next availability >= notAfter becomes Dead. */
  Retry: (input) => checked(failures.Retry(input)),
  /** Known terminal failure with no further retry. */
  Dead: (input) => checked(failures.Dead(input)),
  /** Invalid artifact/invariant requiring investigation; never automatically purged. */
  Isolate: (input) => checked(failures.Isolate(input)),
  /** External effects may have happened; leaves no confirmed finalization for bounded recovery. */
  OutcomeUnknown: (input) => checked(failures.OutcomeUnknown(input))
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobLifecycle.ts
var Counter = Schema7.Int.pipe(
  Schema7.check(Schema7.isBetween({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER }))
);
var LeaseToken = Schema7.String.pipe(
  Schema7.check(
    Schema7.isMinLength(1),
    Schema7.isMaxLength(128),
    Schema7.isPattern(/^[0-9a-f-]+$/iu)
  )
);
var BatchLimit = Schema7.Int.pipe(
  Schema7.check(Schema7.isBetween({ minimum: 1, maximum: 500 }))
);
var JobState = Schema7.Literals([
  "Pending",
  "Active",
  "RetryScheduled",
  "Completed",
  "Dead",
  "Isolated"
]);
var JobOwnership = Schema7.Struct({
  jobId: JobId,
  leaseToken: LeaseToken,
  leaseExpiresAt: EpochMillis,
  lifecycleVersion: Counter
});
var SnapshotStruct = Schema7.Struct({
  jobId: JobId,
  policy: PersistedJobPolicy,
  state: JobState,
  availableAt: EpochMillis,
  updatedAt: EpochMillis,
  attemptsMade: Counter,
  stalledCount: Counter,
  lifecycleVersion: Counter,
  leaseToken: Schema7.NullOr(LeaseToken),
  leaseExpiresAt: Schema7.NullOr(EpochMillis),
  completedAt: Schema7.NullOr(EpochMillis),
  lastFailureCode: Schema7.NullOr(FailureCode)
});
var JobSnapshot = SnapshotStruct.pipe(
  Schema7.check(
    Schema7.makeFilter(
      (row) => row.attemptsMade <= row.policy.maxAttempts && row.stalledCount <= row.policy.maxStalledCount + 1 && (row.state === "Active" ? row.leaseToken !== null && row.leaseExpiresAt !== null && row.completedAt === null : row.leaseToken === null && row.leaseExpiresAt === null) && (row.state === "Completed" || row.state === "Dead" ? row.completedAt !== null : row.completedAt === null) && (!(row.state === "Pending" || row.state === "RetryScheduled" || row.state === "Active") || row.attemptsMade < row.policy.maxAttempts && row.stalledCount <= row.policy.maxStalledCount)
    )
  )
);
var JobFinalization = Schema7.Union([
  Schema7.TaggedStruct("Complete", {}),
  Schema7.TaggedStruct("Retry", {
    code: FailureCode,
    notAfter: Schema7.optional(EpochMillis)
  }),
  Schema7.TaggedStruct("Dead", { code: FailureCode }),
  Schema7.TaggedStruct("Isolate", { code: FailureCode })
]);
var JobFinalizations = Data7.taggedEnum();
var JobLifecycleError = class extends Data7.TaggedError("JobLifecycleError") {
};
var invalid = (reason) => new JobLifecycleError({ reason });
var decodeSnapshot = Schema7.decodeUnknownResult(JobSnapshot, {
  onExcessProperty: "error"
});
var decodeOwnership = Schema7.decodeUnknownResult(JobOwnership, {
  onExcessProperty: "error"
});
var decodeFinalization = Schema7.decodeUnknownResult(JobFinalization, {
  onExcessProperty: "error"
});
var attemptNumber = (row) => row.attemptsMade + 1;
var finalizationFromFailure = (input) => Result2.map(
  Result2.mapError(
    Schema7.decodeUnknownResult(JobFailure, { onExcessProperty: "error" })(input),
    () => invalid("invalid-command")
  ),
  (failure) => failure._tag === "OutcomeUnknown" ? null : failure
);
var internalCodes = define({ stall_limit_exceeded: "stall_limit_exceeded" });

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Capability.ts
import { Data as Data8 } from "effect";
var WorkerCapability = Symbol("effect-jobs/worker/capability");
var JobWorkerUnavailable = class extends Data8.TaggedError("JobWorkerUnavailable") {
};
var JobWorkerNotReady = class extends Data8.TaggedError("JobWorkerNotReady") {
};
var JobWorkerConfigurationError = class extends Data8.TaggedError(
  "JobWorkerConfigurationError"
) {
};
var DispatchResults = Data8.taggedEnum();

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Execution.ts
import { Cause as Cause2, Effect as Effect4, Exit as Exit2, Result as Result3, Schema as Schema8 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobContract.ts
import { Data as Data9 } from "effect";
var EnqueueResults = Data9.taggedEnum();
var jobPayloadFormatVersion = 1;
var maximumJobPayloadBytes = 65536;
var maximumJobSemanticProjectionBytes = 65536;
var maximumProtectedJobPayloadSubtrees = 16;
var maximumJobPayloadSchemaPathBytes = 256;
var maximumJobPayloadDepth = 32;
var InvalidJobInput = class extends Data9.TaggedError("InvalidJobInput") {
};
var JobIntegrityConflict = class extends Data9.TaggedError("JobIntegrityConflict") {
};
var JobPayloadCodecError = class extends Data9.TaggedError("JobPayloadCodecError") {
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Execution.ts
var PreparedMetadata = Schema8.Struct({
  catalog: CatalogIdentity,
  producer: ProducerIdentity,
  policy: PersistedJobPolicy,
  availableAt: Schema8.optional(EpochMillis),
  encoded: Schema8.Struct({
    formatVersion: Schema8.Literal(1),
    payloadBytes: Schema8.declare(
      (value) => value instanceof Uint8Array
    ),
    semanticProjectionBytes: Schema8.declare(
      (value) => value instanceof Uint8Array
    )
  })
});
var policyEquals = Schema8.toEquivalence(PersistedJobPolicy);
var finalizationFor = (exit) => {
  if (Exit2.isSuccess(exit)) {
    return JobFinalizations.Complete();
  }
  const [reason] = exit.cause.reasons;
  if (exit.cause.reasons.length !== 1 || reason === void 0 || !Cause2.isFailReason(reason)) {
    return null;
  }
  if (reason.error instanceof JobPayloadCodecError) {
    return JobFinalizations.Isolate({ code: internalCodes2.invalid_claimed_artifact });
  }
  const result = finalizationFromFailure(reason.error);
  return Result3.isSuccess(result) ? result.success : null;
};
var executionFor = (store, claim, find, supported, responseBudgetMillis) => Effect4.suspend(() => {
  const snapshot2 = Schema8.decodeResult(JobSnapshot, { onExcessProperty: "error" })(
    claim.snapshot
  );
  const owner = Schema8.decodeResult(JobOwnership, { onExcessProperty: "error" })(
    claim.ownership
  );
  if (Result3.isFailure(snapshot2) || Result3.isFailure(owner)) {
    return Effect4.void;
  }
  const before = snapshot2.success;
  const ownership = owner.success;
  if (before.state !== "Active" || before.jobId !== ownership.jobId || before.leaseToken !== ownership.leaseToken || before.leaseExpiresAt !== ownership.leaseExpiresAt || before.lifecycleVersion !== ownership.lifecycleVersion) {
    return Effect4.void;
  }
  const finalize = (finalization) => {
    const request = Object.freeze({
      ownership: Object.freeze(ownership),
      before: Object.freeze({
        ...before,
        policy: Object.freeze({
          ...before.policy,
          retrySchedule: Object.freeze({ ...before.policy.retrySchedule }),
          completedRetention: Object.freeze({ ...before.policy.completedRetention }),
          deadRetention: Object.freeze({ ...before.policy.deadRetention })
        })
      }),
      finalization: Object.freeze(finalization)
    });
    const write = () => Effect4.suspend(() => store.finalize(request)).pipe(
      Effect4.timeoutOrElse({
        duration: responseBudgetMillis,
        orElse: () => Effect4.succeed({ _tag: "Unknown" })
      }),
      observe("finalize", "finalization")
    );
    return Effect4.gen(function* () {
      const result = yield* write();
      if (result._tag === "Applied") {
        return result;
      }
      const reconciled = yield* Effect4.suspend(
        () => store.reconcileFinalization(request)
      ).pipe(
        Effect4.timeout(responseBudgetMillis),
        observe("finalize", "reconciliation")
      );
      if (reconciled._tag === "StillOwned") {
        return yield* write();
      }
      return reconciled._tag === "Applied" ? { _tag: "Applied" } : { _tag: "Unknown" };
    }).pipe(observe("finalize", "protocol"), Effect4.ignore);
  };
  return Effect4.gen(function* () {
    const prepared = yield* Schema8.decodeUnknownEffect(PreparedMetadata)(
      claim.prepared,
      { onExcessProperty: "error" }
    ).pipe(Effect4.result);
    if (Result3.isFailure(prepared) || !policyEquals(prepared.success.policy, before.policy)) {
      return yield* finalize(
        JobFinalizations.Isolate({ code: internalCodes2.invalid_claimed_artifact })
      );
    }
    const { catalog, producer, encoded } = prepared.success;
    if (!supported.some(
      (entry) => entry.queue === catalog.queue && entry.kind === catalog.kind && entry.version === catalog.version
    )) {
      return;
    }
    const handler = find(catalog);
    if (handler === void 0) {
      return;
    }
    if (encoded.payloadBytes.byteLength > 65536 || encoded.semanticProjectionBytes.byteLength > 65536) {
      return yield* finalize(
        JobFinalizations.Isolate({ code: internalCodes2.invalid_claimed_artifact })
      );
    }
    const context = Object.freeze({
      jobId: before.jobId,
      catalog: Object.freeze(catalog),
      producer: Object.freeze(producer),
      attemptNumber: attemptNumber(before)
    });
    const copied = {
      formatVersion: encoded.formatVersion,
      payloadBytes: new Uint8Array(encoded.payloadBytes),
      semanticProjectionBytes: new Uint8Array(encoded.semanticProjectionBytes)
    };
    const exit = yield* Effect4.suspend(() => handler.execute(copied, context)).pipe(
      observe("execute", "handler"),
      Effect4.exit
    );
    const finalization = finalizationFor(exit);
    if (finalization !== null) {
      yield* finalize(finalization);
    }
  }).pipe(Effect4.timeout(before.policy.attemptTimeoutMillis), Effect4.ignore);
});
var internalCodes2 = define({
  invalid_claimed_artifact: "invalid_claimed_artifact"
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobWorker.ts
var JobWorker = class extends Context2.Service()(
  "effect-jobs/JobWorker"
) {
};
var unavailable = (effect) => effect.pipe(
  Effect5.catchCause(
    (cause) => Cause3.hasInterrupts(cause) ? Effect5.interrupt : Effect5.fail(new JobWorkerUnavailable())
  )
);
var make3 = (store, options) => Effect5.gen(function* () {
  const registry = yield* JobRegistry;
  const services = yield* Effect5.context();
  const budget = options.operationResponseBudgetMillis;
  if (!Schema9.is(EpochMillis)(budget)) {
    return yield* new JobWorkerConfigurationError({
      field: "operationResponseBudgetMillis"
    });
  }
  const catalogs = options.catalog.map(
    (entry) => Object.freeze({
      queue: entry.catalog.queue,
      kind: entry.catalog.kind,
      version: entry.catalog.version
    })
  );
  const keys = catalogs.map(
    (entry) => `${entry.queue}\0${entry.kind}\0${entry.version}`
  );
  if (catalogs.length === 0 || !catalogs.every(Schema9.is(CatalogIdentity)) || new Set(keys).size !== keys.length) {
    return yield* new JobWorkerConfigurationError({ field: "catalog" });
  }
  Object.freeze(catalogs);
  const bound = {
    claim: (input) => Effect5.suspend(() => store.claim(input)).pipe(Effect5.provide(services)),
    reconcileClaim: (token) => Effect5.suspend(() => store.reconcileClaim(token)).pipe(Effect5.provide(services)),
    release: (owner, phase) => Effect5.suspend(() => store.release(owner, phase)).pipe(Effect5.provide(services)),
    finalize: (request) => Effect5.suspend(() => store.finalize(request)).pipe(Effect5.provide(services)),
    reconcileFinalization: (request) => Effect5.suspend(() => store.reconcileFinalization(request)).pipe(
      Effect5.provide(services)
    ),
    recoverExpired: (limit) => Effect5.suspend(() => store.recoverExpired(limit)).pipe(Effect5.provide(services))
  };
  const permits = /* @__PURE__ */ new Map();
  const ready = (queue) => Effect5.suspend(
    () => catalogs.some((entry) => entry.queue === queue) && catalogs.every((entry) => registry.find(entry) !== void 0) ? Effect5.void : Effect5.fail(new JobWorkerNotReady())
  );
  const release = (ownership) => bound.release(ownership, "BeforeExecution").pipe(
    Effect5.interruptible,
    Effect5.timeout(budget),
    observe("release", "dispatch"),
    Effect5.ignore
  );
  const started = (claim, token, queue) => {
    if (!Schema9.is(JobOwnership)(claim.ownership) || claim.ownership.leaseToken !== token) {
      return DispatchResults.Unresolved();
    }
    let phase = "BeforeExecution";
    return DispatchResults.Started({
      execution: Effect5.suspend(() => {
        if (phase !== "BeforeExecution") {
          return Effect5.void;
        }
        phase = "Executing";
        return executionFor(
          bound,
          claim,
          registry.find,
          catalogs.filter((entry) => entry.queue === queue),
          budget
        );
      }),
      release: Effect5.suspend(() => {
        if (phase !== "BeforeExecution") {
          return Effect5.void;
        }
        phase = "Released";
        return release(claim.ownership);
      })
    });
  };
  const capability = {
    ready,
    permits: (consumer) => Effect5.suspend(() => {
      const existing = permits.get(consumer.queue.name);
      if (existing !== void 0) {
        if (existing.concurrency !== consumer.localConcurrency) {
          return Effect5.fail(new JobWorkerConfigurationError({ field: "consumer" }));
        }
        return Effect5.succeed(existing.semaphore);
      }
      const semaphore = Semaphore.makeUnsafe(consumer.localConcurrency);
      permits.set(consumer.queue.name, {
        concurrency: consumer.localConcurrency,
        semaphore
      });
      return Effect5.succeed(semaphore);
    }),
    claim: (queue) => Effect5.gen(function* () {
      yield* ready(queue);
      const token = yield* Effect5.sync(() => globalThis.crypto.randomUUID());
      const result = yield* bound.claim({
        queue,
        supportedCatalog: catalogs.filter((entry) => entry.queue === queue),
        leaseToken: token
      }).pipe(
        Effect5.timeoutOrElse({
          duration: budget,
          orElse: () => Effect5.succeed({ _tag: "Unknown" })
        }),
        observe("claim", "dispatch")
      );
      if (result._tag === "Empty") {
        return DispatchResults.Empty();
      }
      if (result._tag === "Claimed") {
        return started(result.claim, token, queue);
      }
      const reconciled = yield* bound.reconcileClaim(token).pipe(Effect5.timeout(budget), observe("claim", "reconciliation"));
      if (reconciled._tag === "Owned") {
        return started(reconciled.claim, token, queue);
      }
      if (reconciled._tag === "InsufficientLease") {
        if (!Schema9.is(JobOwnership)(reconciled.ownership) || reconciled.ownership.leaseToken !== token) {
          return DispatchResults.Unresolved();
        }
        yield* release(reconciled.ownership);
        return DispatchResults.Unresolved();
      }
      return DispatchResults.Unresolved();
    }).pipe(unavailable),
    recover: (limit) => Effect5.gen(function* () {
      let recovered = 0;
      for (let remaining = limit; remaining > 0; ) {
        const batch = Math.min(500, remaining);
        const count = yield* bound.recoverExpired(batch).pipe(Effect5.timeout(budget), observe("recover-expired", "maintenance"));
        if (!Number.isInteger(count) || count < 0 || count > batch) {
          return yield* new JobWorkerUnavailable();
        }
        recovered += count;
        remaining -= batch;
        if (count < batch) {
          break;
        }
      }
      return recovered;
    }).pipe(unavailable)
  };
  return JobWorker.of(Object.freeze({ [WorkerCapability]: capability }));
});
var layer2 = (store, options) => Layer2.effect(JobWorker, make3(store, options));

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Results.ts
import { Data as Data10 } from "effect";
var DrainResults = Data10.taggedEnum();

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/worker/Drain.ts
var drainWithOptions = (consumer, options = {}) => Effect6.gen(function* () {
  const worker = yield* JobWorker;
  const runtime = worker[WorkerCapability];
  yield* runtime.ready(consumer.queue.name);
  const permits = yield* runtime.permits(consumer);
  const recovery = yield* (options.recover === false ? Effect6.succeed(0) : runtime.recover(consumer.recoveryLimitPerRun)).pipe(Effect6.result);
  if (recovery._tag === "Failure") {
    return DrainResults.Backoff({ phase: "recovery", claimed: 0 });
  }
  return yield* Effect6.scoped(
    Effect6.gen(function* () {
      const executions = [];
      let claimed = 0;
      const install = (started, restore) => Effect6.gen(function* () {
        yield* restore(options.beforeExecutionBoundary ?? Effect6.void).pipe(
          Effect6.onInterrupt(() => started.release)
        );
        const fiber = yield* restore(started.execution).pipe(
          Effect6.ensuring(Semaphore2.release(permits, 1)),
          Effect6.forkScoped
        );
        executions.push(fiber);
      });
      let terminal = "Limit";
      for (; claimed < consumer.claimLimitPerRun; claimed++) {
        const result = yield* Effect6.uninterruptibleMask(
          (restore) => Effect6.gen(function* () {
            yield* restore(Semaphore2.take(permits, 1));
            let transferred = false;
            return yield* restore(runtime.claim(consumer.queue.name)).pipe(
              Effect6.flatMap((dispatch) => {
                if (dispatch._tag !== "Started") {
                  return Effect6.succeed(dispatch._tag);
                }
                return install(dispatch, restore).pipe(
                  Effect6.tap(
                    () => Effect6.sync(() => {
                      transferred = true;
                    })
                  ),
                  Effect6.as("Started")
                );
              }),
              Effect6.ensuring(
                Effect6.suspend(
                  () => transferred ? Effect6.void : Semaphore2.release(permits, 1)
                )
              )
            );
          })
        ).pipe(Effect6.result);
        if (result._tag === "Failure") {
          terminal = "Failed";
          break;
        }
        if (result.success !== "Started") {
          terminal = result.success;
          break;
        }
      }
      yield* Effect6.forEach(executions, Fiber.await, { discard: true });
      if (terminal === "Failed" || terminal === "Unresolved") {
        return DrainResults.Backoff({
          phase: terminal === "Failed" ? "claim" : "reconciliation",
          claimed
        });
      }
      return terminal === "Empty" ? DrainResults.Idle({ claimed, recovered: recovery.success }) : DrainResults.MoreWork({ claimed, recovered: recovery.success });
    })
  );
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobWorkerRuntime.ts
var drain = (consumer) => drainWithOptions(consumer);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/PostgreSqlJobs.ts
import { Context as Context4, Effect as Effect8, Layer as Layer3, Schema as Schema10 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobEnqueue.ts
import { Context as Context3, Data as Data11 } from "effect";
var JobBackendError = class extends Data11.TaggedError("JobBackendError") {
};
var JobEnqueue = class extends Context3.Service()(
  "effect-jobs/JobEnqueue"
) {
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/JobTransaction.ts
import { Effect as Effect7 } from "effect";
var JobsTransactionTypeId = Symbol("effect-jobs/JobsTransaction");
var insertPrepared = (transaction, prepared) => transaction[JobsTransactionTypeId].insertOrCompare(prepared);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/PostgreSqlJobs.ts
var PostgreSqlJobs = class extends Context4.Service()(
  "effect-jobs/PostgreSqlJobs"
) {
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/persistence/commands/Transactions.ts
import { Context as Context6, Effect as Effect10, Layer as Layer4, Schema as Schema14 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/packages/playground-contracts/src/Scenarios.ts
import { Schema as Schema12 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/packages/playground-contracts/src/Sandbox.ts
import { Schema as Schema11 } from "effect";
var opaque = Schema11.String.pipe(
  Schema11.check(Schema11.isMinLength(1), Schema11.isMaxLength(128))
);
var SandboxId = opaque.pipe(Schema11.brand("playground/SandboxId"));
var Generation = Schema11.Int.pipe(
  Schema11.check(Schema11.isBetween({ minimum: 1, maximum: Number.MAX_SAFE_INTEGER }))
);
var SandboxRef = Schema11.Struct({ sandboxId: SandboxId, generation: Generation });
var Capabilities = Schema11.Struct({
  runScenario: Schema11.Boolean,
  resetSandbox: Schema11.Boolean,
  retryJob: Schema11.Boolean,
  cancelJob: Schema11.Boolean,
  redriveJob: Schema11.Boolean
});
var SandboxView = Schema11.Struct({
  ref: SandboxRef,
  expiresAt: EpochMillis,
  capabilities: Capabilities
});
var limits = Object.freeze({
  pageSize: 50,
  jobsPerSandbox: 100,
  scenarioBatch: 10,
  sandboxLifetimeMillis: 36e5,
  reconciliationMillis: 5e3
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/packages/playground-contracts/src/Scenarios.ts
var ScenarioId = Schema12.Literals([
  "success",
  "retry-then-success",
  "terminal-failure",
  "unknown-outcome",
  "deduplication"
]);
var RequestId = Schema12.String.pipe(
  Schema12.check(Schema12.isMinLength(1), Schema12.isMaxLength(128))
);
var ScenarioCommand = Schema12.Struct({
  sandbox: SandboxRef,
  requestId: RequestId,
  scenario: ScenarioId,
  count: Schema12.Int.pipe(Schema12.check(Schema12.isBetween({ minimum: 1, maximum: 10 })))
});
var ScenarioResult = Schema12.Union([
  Schema12.TaggedStruct("Committed", {
    sandbox: SandboxRef,
    requestId: RequestId,
    jobIds: Schema12.Array(JobId).pipe(
      Schema12.check(Schema12.isMinLength(1), Schema12.isMaxLength(10))
    )
  }),
  Schema12.TaggedStruct("OutcomeUnknown", { sandbox: SandboxRef, requestId: RequestId })
]);
var ResetCommand = Schema12.Struct({ sandbox: SandboxRef, requestId: RequestId });
var ResetResult = Schema12.Union([
  Schema12.TaggedStruct("Committed", {
    previous: SandboxRef,
    current: SandboxRef,
    requestId: RequestId
  }),
  Schema12.TaggedStruct("OutcomeUnknown", { previous: SandboxRef, requestId: RequestId })
]).pipe(
  Schema12.check(
    Schema12.makeFilter(
      (result) => result._tag === "OutcomeUnknown" || result.previous.sandboxId === result.current.sandboxId && result.current.generation === result.previous.generation + 1
    )
  )
);
var ReceiptRequest = Schema12.Struct({ sandbox: SandboxRef, requestId: RequestId });

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/packages/playground-contracts/src/Services.ts
import { Context as Context5, Schema as Schema13 } from "effect";
var PublicErrorCode = Schema13.Literals([
  "invalid-request",
  "not-found",
  "sandbox-expired",
  "stale-generation",
  "limit-reached",
  "capability-unavailable",
  "unavailable"
]);
var PublicError = Schema13.Struct({ code: PublicErrorCode });
var PlaygroundError = class extends Schema13.TaggedError()(
  "PlaygroundError",
  { code: PublicErrorCode }
) {
};
var SandboxAuthority = class extends Context5.Service()("playground/SandboxAuthority") {
};
var JobsRead = class extends Context5.Service()("playground/JobsRead") {
};
var Scenarios = class extends Context5.Service()("playground/Scenarios") {
};
var Changes = class extends Context5.Service()("playground/Changes") {
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/persistence/commands/Transactions.ts
var StoredReceipt = Schema14.Union([
  Schema14.TaggedStruct("Scenario", {
    command: ScenarioCommand,
    result: ScenarioResult.members[0]
  }),
  Schema14.TaggedStruct("Reset", { command: ResetCommand, result: ResetResult })
]);
var CommandTransactionFailure = class extends Schema14.TaggedError()(
  "CommandTransactionFailure",
  { commitKnowledge: Schema14.Literals(["NotCommitted", "Unknown"]) }
) {
};
var CommandTransactions = class extends Context6.Service()("playground/CommandTransactions") {
};
var CommandPersistence = class extends Context6.Service()("playground/CommandPersistence") {
};
var unavailable2 = () => Effect10.fail(new PlaygroundError({ code: "capability-unavailable" }));
var unavailableLayer = Layer4.succeed(
  CommandPersistence,
  CommandPersistence.of({
    run: unavailable2,
    reset: unavailable2,
    scenarioReceipt: unavailable2,
    resetReceipt: unavailable2
  })
);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/Definitions.ts
import { Schema as Schema21 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/Job.ts
import { Data as Data12, Effect as Effect14, Layer as Layer5, Schema as Schema17 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobPayloadCodec.ts
import { Cause as Cause4, Effect as Effect13, Schema as Schema16, SchemaAST as SchemaAST2 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/codec/CanonicalJson.ts
import { Effect as Effect11 } from "effect";
var encoder = new TextEncoder();
var validScalars2 = (value) => {
  for (const scalar of value) {
    const code = scalar.codePointAt(0);
    if (code >= 55296 && code <= 57343) {
      return false;
    }
  }
  return true;
};
var canonicalText = (value, maximum, reason, rootDepth = 0) => {
  const seen = /* @__PURE__ */ new Set();
  let length = 0;
  const emit = (text) => {
    length += encoder.encode(text).byteLength;
    if (length > maximum) {
      throw new JobPayloadCodecError({ reason });
    }
    return text;
  };
  const quote = (text) => {
    if (text.length > maximum) {
      throw new JobPayloadCodecError({ reason });
    }
    if (!validScalars2(text)) {
      throw new JobPayloadCodecError({ reason: "invalid-json-value" });
    }
    return emit(JSON.stringify(text));
  };
  const visit = (item, depth) => {
    if (depth > maximumJobPayloadDepth) {
      throw new JobPayloadCodecError({ reason: "payload-too-deep" });
    }
    if (item === null) {
      return emit("null");
    }
    switch (typeof item) {
      case "boolean":
        return emit(JSON.stringify(item));
      case "string":
        return quote(item);
      case "number":
        if (Number.isFinite(item)) {
          return emit(JSON.stringify(item));
        }
        break;
      case "object": {
        if (seen.has(item)) {
          break;
        }
        const array = Array.isArray(item);
        if (!array && Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
          break;
        }
        seen.add(item);
        const descriptors = Object.getOwnPropertyDescriptors(item);
        const keys = Reflect.ownKeys(descriptors);
        for (const key2 of keys) {
          if (array && key2 === "length") {
            continue;
          }
          const descriptor = descriptors[key2];
          if (typeof key2 !== "string" || !validScalars2(key2) || !descriptor.enumerable || !("value" in descriptor)) {
            throw new JobPayloadCodecError({ reason: "invalid-json-value" });
          }
        }
        let text;
        if (array) {
          emit("[]");
          if (keys.length !== item.length + 1) {
            throw new JobPayloadCodecError({ reason: "invalid-json-value" });
          }
          const entries = [];
          for (let index = 0; index < item.length; index++) {
            if (index > 0) {
              emit(",");
            }
            const descriptor = descriptors[String(index)];
            if (descriptor === void 0) {
              throw new JobPayloadCodecError({ reason: "invalid-json-value" });
            }
            entries.push(visit(descriptor.value, depth + 1));
          }
          text = `[${entries.join(",")}]`;
        } else {
          emit("{}");
          text = `{${keys.sort().map((key2, index) => {
            if (index > 0) {
              emit(",");
            }
            return `${quote(key2)}${emit(":")}${visit(descriptors[key2].value, depth + 1)}`;
          }).join(",")}}`;
        }
        seen.delete(item);
        return text;
      }
    }
    throw new JobPayloadCodecError({ reason: "invalid-json-value" });
  };
  return visit(value, rootDepth);
};
var canonicalBytes = (value, maximum, reason, rootDepth = 0) => Effect11.try({
  try: () => {
    const bytes = encoder.encode(canonicalText(value, maximum, reason, rootDepth));
    if (bytes.byteLength > maximum) {
      throw new JobPayloadCodecError({ reason });
    }
    return bytes;
  },
  catch: (error) => error instanceof JobPayloadCodecError ? error : new JobPayloadCodecError({ reason: "invalid-json-value" })
});
var bytesEqual = (left, right) => left.length === right.length && left.every((byte, index) => byte === right[index]);
var checkDecodedContainers = (value) => Effect11.try({
  try: () => {
    const seen = /* @__PURE__ */ new Set();
    const visit = (item, depth) => {
      if (depth > maximumJobPayloadDepth) {
        throw new JobPayloadCodecError({ reason: "payload-too-deep" });
      }
      if (typeof item === "number" && !Number.isFinite(item)) {
        throw new JobPayloadCodecError({ reason: "invalid-json-value" });
      }
      if (item === null || typeof item !== "object") {
        return;
      }
      if (!Array.isArray(item) && Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
        return;
      }
      if (seen.has(item)) {
        throw new JobPayloadCodecError({ reason: "invalid-json-value" });
      }
      seen.add(item);
      const descriptors = Object.getOwnPropertyDescriptors(item);
      if (Array.isArray(item)) {
        if (Reflect.ownKeys(descriptors).length !== item.length + 1) {
          throw new JobPayloadCodecError({ reason: "invalid-json-value" });
        }
        for (let index = 0; index < item.length; index++) {
          if (!Object.hasOwn(descriptors, String(index))) {
            throw new JobPayloadCodecError({ reason: "invalid-json-value" });
          }
        }
      }
      for (const key2 of Reflect.ownKeys(descriptors)) {
        if (Array.isArray(item) && key2 === "length") {
          continue;
        }
        const descriptor = descriptors[key2];
        if (typeof key2 !== "string" || !validScalars2(key2) || !descriptor.enumerable || !("value" in descriptor)) {
          throw new JobPayloadCodecError({ reason: "invalid-json-value" });
        }
        visit(descriptor.value, depth + 1);
      }
      seen.delete(item);
    };
    visit(value, 0);
  },
  catch: (error) => error instanceof JobPayloadCodecError ? error : new JobPayloadCodecError({ reason: "invalid-json-value" })
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/codec/ProtectedProjection.ts
import { Effect as Effect12, Schema as Schema15, SchemaAST } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/codec/EncryptedBoundary.ts
var links = /* @__PURE__ */ new WeakSet();
var registerEncryption = (link) => {
  links.add(link.transformation);
};
var hasEncryption = (ast) => ast.encoding?.some((link) => links.has(link.transformation)) ?? false;

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/internal/codec/ProtectedProjection.ts
var marked = (ast) => ast.annotations?.effectJobsProtectedPayload === true;
var encoder2 = new TextEncoder();
var prepareProjection = (schema) => Effect12.try({
  try: () => {
    const visit = (ast, transformed, protectedParent, ancestors) => {
      if (ancestors.has(ast) || SchemaAST.isSuspend(ast)) {
        throw new JobPayloadCodecError({ reason: "invalid-schema" });
      }
      if (hasEncryption(ast)) {
        if (transformed || protectedParent) {
          throw new JobPayloadCodecError({ reason: "invalid-schema" });
        }
        visit(SchemaAST.toEncoded(ast), false, false, ancestors);
        return;
      }
      const boundary = transformed || ast.encoding !== void 0;
      const protectedHere = marked(ast);
      if (protectedHere && (boundary || protectedParent)) {
        throw new JobPayloadCodecError({ reason: "invalid-schema" });
      }
      ancestors.add(ast);
      const child = (node) => visit(node, boundary, protectedParent || protectedHere, ancestors);
      if (SchemaAST.isObjects(ast)) {
        if (ast.indexSignatures.length > 0 || ast.propertySignatures.some((property) => typeof property.name !== "string")) {
          throw new JobPayloadCodecError({ reason: "invalid-schema" });
        }
        ast.propertySignatures.forEach((property) => child(property.type));
      } else if (SchemaAST.isArrays(ast)) {
        if (ast.elements.length !== 0 || ast.rest.length !== 1) {
          throw new JobPayloadCodecError({ reason: "invalid-schema" });
        }
        ast.rest.forEach(child);
      } else if (SchemaAST.isUnion(ast)) {
        ast.types.forEach(child);
      } else if (SchemaAST.isDeclaration(ast)) {
        if (ast.encoding === void 0) {
          throw new JobPayloadCodecError({ reason: "invalid-schema" });
        }
        ast.typeParameters.forEach(child);
      }
      ast.encoding?.forEach((link) => child(link.to));
      ancestors.delete(ast);
    };
    visit(schema.ast, false, false, /* @__PURE__ */ new Set());
    const encoded = SchemaAST.toEncoded(schema.ast);
    visit(encoded, false, false, /* @__PURE__ */ new Set());
    return encoded;
  },
  catch: () => new JobPayloadCodecError({ reason: "invalid-schema" })
});
var project = (ast, value) => Effect12.try({
  try: () => {
    let count = 0;
    const protectedFields = [];
    const visit = (node, item, path) => {
      if (encoder2.encode(path).byteLength > maximumJobPayloadSchemaPathBytes) {
        throw new JobPayloadCodecError({ reason: "schema-path-too-long" });
      }
      if (marked(node)) {
        if (++count > maximumProtectedJobPayloadSubtrees) {
          throw new JobPayloadCodecError({ reason: "too-many-protected-subtrees" });
        }
        if (item === null || typeof item !== "object" || Array.isArray(item) || !Object.hasOwn(item, "fingerprint")) {
          throw new JobPayloadCodecError({ reason: "invalid-protected-value" });
        }
        const fingerprint = Object.getOwnPropertyDescriptor(item, "fingerprint");
        if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null || !fingerprint.enumerable || !("value" in fingerprint)) {
          throw new JobPayloadCodecError({ reason: "invalid-json-value" });
        }
        protectedFields.push([path, fingerprint.value]);
        return null;
      }
      if (SchemaAST.isUnion(node)) {
        const branch = node.types.find(
          (member) => Schema15.decodeUnknownExit(Schema15.make(member), {
            onExcessProperty: "error"
          })(item)._tag === "Success"
        );
        if (branch === void 0) {
          throw new JobPayloadCodecError({ reason: "invalid-schema" });
        }
        return visit(branch, item, path);
      }
      if (SchemaAST.isArrays(node) && Array.isArray(item)) {
        return item.map(
          (entry, index) => visit(node.rest[0], entry, `${path}/${index}`)
        );
      }
      if (SchemaAST.isObjects(node) && item !== null && typeof item === "object") {
        if (Object.getPrototypeOf(item) !== Object.prototype && Object.getPrototypeOf(item) !== null) {
          throw new JobPayloadCodecError({ reason: "invalid-json-value" });
        }
        return Object.fromEntries(
          Object.entries(item).map(([key2, entry]) => {
            const property = node.propertySignatures.find((field) => field.name === key2);
            return [
              key2,
              property === void 0 ? entry : visit(
                property.type,
                entry,
                `${path}/${key2.replaceAll("~", "~0").replaceAll("/", "~1")}`
              )
            ];
          })
        );
      }
      return item;
    };
    const data = visit(ast, value, "");
    return { data, protected: Object.fromEntries(protectedFields) };
  },
  catch: (error) => error instanceof JobPayloadCodecError ? error : new JobPayloadCodecError({ reason: "invalid-schema" })
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobPayloadCodec.ts
var strict = { onExcessProperty: "error" };
var encodeJobPayload = Effect13.fnUntraced(function* (schema, payload) {
  const ast = yield* prepareProjection(schema);
  yield* checkDecodedContainers(payload);
  yield* project(SchemaAST2.toType(schema.ast), payload);
  const value = yield* Schema16.encodeEffect(
    schema,
    strict
  )(payload).pipe(
    Effect13.catchCause(
      (cause) => Effect13.failCause(
        Cause4.map(cause, () => new JobPayloadCodecError({ reason: "invalid-schema" }))
      )
    )
  );
  const payloadBytes = yield* canonicalBytes(
    value,
    maximumJobPayloadBytes,
    "payload-too-large"
  );
  yield* Schema16.decodeUnknownEffect(
    Schema16.make(ast),
    strict
  )(value).pipe(
    Effect13.catchCause(
      (cause) => Effect13.failCause(
        Cause4.map(cause, () => new JobPayloadCodecError({ reason: "invalid-schema" }))
      )
    )
  );
  const projection = yield* project(ast, value);
  const semanticProjectionBytes = yield* canonicalBytes(
    projection,
    maximumJobSemanticProjectionBytes,
    "projection-too-large",
    // The representation envelope is not an application-data depth level.
    -1
  );
  return { formatVersion: jobPayloadFormatVersion, payloadBytes, semanticProjectionBytes };
});
var readArtifact = (encoded) => Effect13.try({
  try: () => {
    if (encoded.formatVersion !== jobPayloadFormatVersion || !(encoded.payloadBytes instanceof Uint8Array) || !(encoded.semanticProjectionBytes instanceof Uint8Array)) {
      throw new JobPayloadCodecError({ reason: "invalid-encoding" });
    }
    if (encoded.payloadBytes.byteLength > maximumJobPayloadBytes) {
      throw new JobPayloadCodecError({ reason: "payload-too-large" });
    }
    if (encoded.semanticProjectionBytes.byteLength > maximumJobSemanticProjectionBytes) {
      throw new JobPayloadCodecError({ reason: "projection-too-large" });
    }
    return {
      payloadBytes: new Uint8Array(encoded.payloadBytes),
      semanticProjectionBytes: new Uint8Array(encoded.semanticProjectionBytes)
    };
  },
  catch: (error) => error instanceof JobPayloadCodecError ? error : new JobPayloadCodecError({ reason: "invalid-encoding" })
});
var parse2 = (bytes) => Effect13.try({
  try: () => JSON.parse(
    new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes)
  ),
  catch: () => new JobPayloadCodecError({ reason: "invalid-encoding" })
});
var decodeJobPayload = Effect13.fnUntraced(function* (schema, encoded) {
  const snapshot2 = yield* readArtifact(encoded);
  const ast = yield* prepareProjection(schema);
  const value = yield* parse2(snapshot2.payloadBytes);
  const payloadBytes = yield* canonicalBytes(
    value,
    maximumJobPayloadBytes,
    "payload-too-large"
  );
  const suppliedProjection = yield* parse2(snapshot2.semanticProjectionBytes);
  const suppliedBytes = yield* canonicalBytes(
    suppliedProjection,
    maximumJobSemanticProjectionBytes,
    "projection-too-large",
    -1
  );
  if (!bytesEqual(payloadBytes, snapshot2.payloadBytes) || !bytesEqual(suppliedBytes, snapshot2.semanticProjectionBytes)) {
    return yield* new JobPayloadCodecError({ reason: "invalid-encoding" });
  }
  yield* Schema16.decodeUnknownEffect(
    Schema16.make(ast),
    strict
  )(value).pipe(
    Effect13.catchCause(
      (cause) => Effect13.failCause(
        Cause4.map(cause, () => new JobPayloadCodecError({ reason: "invalid-schema" }))
      )
    )
  );
  const projection = yield* project(ast, value);
  const projectionBytes = yield* canonicalBytes(
    projection,
    maximumJobSemanticProjectionBytes,
    "projection-too-large",
    -1
  );
  if (!bytesEqual(projectionBytes, snapshot2.semanticProjectionBytes)) {
    return yield* new JobPayloadCodecError({ reason: "projection-mismatch" });
  }
  const decoded = yield* Schema16.decodeUnknownEffect(
    schema,
    strict
  )(value).pipe(
    Effect13.catchCause(
      (cause) => Effect13.failCause(
        Cause4.map(cause, () => new JobPayloadCodecError({ reason: "invalid-schema" }))
      )
    )
  );
  yield* checkDecodedContainers(decoded);
  return decoded;
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/Job.ts
var InvalidJobDefinition = class extends Data12.TaggedError("InvalidJobDefinition") {
};
function make4(options) {
  const { kind, queue, payload } = options;
  const version = options.version === void 0 ? 1 : options.version;
  const encodePayload = options.encodePayload ?? encodeJobPayload;
  const catalog = Object.freeze({ queue: queue.name, kind, version });
  if (!Schema17.is(CatalogIdentity)(catalog) || !Schema17.isSchema(payload)) {
    throw new InvalidJobDefinition({
      expected: "valid queue/kind/version and payload Schema"
    });
  }
  const prepare = Effect14.fnUntraced(function* (input) {
    if (!Schema17.is(ProducerIdentity)(input.producer)) {
      return yield* new InvalidJobInput({ field: "producer" });
    }
    if (!Schema17.is(PersistedJobPolicy)(input.policy)) {
      return yield* new InvalidJobInput({ field: "policy" });
    }
    if (input.availableAt !== void 0 && !Schema17.is(EpochMillis)(input.availableAt)) {
      return yield* new InvalidJobInput({ field: "availableAt" });
    }
    const producer = Object.freeze({
      operation: input.producer.operation,
      operationId: input.producer.operationId,
      slot: input.producer.slot
    });
    const policy = Object.freeze({
      ...input.policy,
      retrySchedule: Object.freeze({ ...input.policy.retrySchedule }),
      completedRetention: Object.freeze({ ...input.policy.completedRetention }),
      deadRetention: Object.freeze({ ...input.policy.deadRetention })
    });
    const availableAt = input.availableAt;
    const encoded = yield* encodePayload(payload, input.payload);
    return Object.freeze({
      catalog,
      producer,
      policy,
      encoded,
      ...availableAt === void 0 ? {} : { availableAt }
    });
  });
  return Object.freeze({
    kind,
    version,
    queue,
    payload,
    catalog,
    enqueue: Effect14.fnUntraced(function* (input) {
      const backend = yield* JobEnqueue;
      return yield* backend.enqueue(prepare(input));
    }),
    enqueueStandalone: Effect14.fnUntraced(function* (input) {
      const backend = yield* JobEnqueue;
      return yield* backend.enqueueStandalone(prepare(input));
    }),
    enqueueInTransaction: Effect14.fnUntraced(function* (tx, input) {
      return yield* insertPrepared(tx, yield* prepare(input));
    }),
    handlerLayer: (execute2, decodePayload) => Layer5.effectDiscard(
      Effect14.gen(function* () {
        const registry = yield* JobRegistry;
        const services = yield* Effect14.context();
        yield* registry.install({
          catalog,
          execute: (encoded, context) => Effect14.flatMap(
            decodePayload(payload, encoded),
            (decoded) => Effect14.suspend(() => execute2({ payload: decoded, context }))
          ).pipe(Effect14.provide(services))
        });
      })
    )
  });
}

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobProducer.ts
var make5 = (options) => {
  validateProducerDeclaration(options);
  const operation = options.operation;
  const slots = Object.freeze([...options.slots]);
  return Object.freeze({
    operation,
    slots,
    identity: (input) => {
      validateOperationId(input.operationId);
      if (!slots.includes(input.slot)) {
        throw new JobDeclarationError({ field: "slots", expected: "a declared slot" });
      }
      return Object.freeze({
        operation,
        operationId: input.operationId,
        slot: input.slot
      });
    }
  });
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobQueue.ts
import { Data as Data13, Schema as Schema18 } from "effect";
var JobQueueTypeId = Symbol("effect-jobs/JobQueue");
var InvalidJobQueue = class extends Data13.TaggedError("InvalidJobQueue") {
};
var make6 = (name2) => {
  if (!Schema18.is(QueueName)(name2)) {
    throw new InvalidJobQueue({
      expected: "1\u201364 ASCII characters matching ^[a-z][a-z0-9.-]*$"
    });
  }
  const queue = { [JobQueueTypeId]: JobQueueTypeId, name: name2 };
  return Object.freeze(queue);
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/PrivateDocument.ts
import { Context as Context7, Effect as Effect16, Layer as Layer6, Schema as Schema20 } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/src/JobPayload.ts
import { Cause as Cause5, Data as Data14, Effect as Effect15, Schema as Schema19, SchemaAST as SchemaAST3, SchemaGetter, SchemaIssue } from "effect";
var protectedPayload = (schema) => schema.annotate({ effectJobsProtectedPayload: true });
var JobEncryptionError = class extends Data14.TaggedError("JobEncryptionError") {
};
var InvalidEncryptedSchema = class extends Data14.TaggedError("InvalidEncryptedSchema") {
};
var inspectDomain = (ast, ancestors = /* @__PURE__ */ new Set()) => {
  if (hasEncryption(ast) || ast.annotations?.effectJobsProtectedPayload) {
    throw new InvalidEncryptedSchema({ reason: "nested-encryption" });
  }
  if (ancestors.has(ast) || SchemaAST3.isSuspend(ast)) {
    throw new InvalidEncryptedSchema({ reason: "recursive-schema" });
  }
  ancestors.add(ast);
  if (SchemaAST3.isObjects(ast)) {
    ast.propertySignatures.forEach((p) => inspectDomain(p.type, ancestors));
    ast.indexSignatures.forEach((p) => {
      inspectDomain(p.parameter, ancestors);
      inspectDomain(p.type, ancestors);
    });
  }
  if (SchemaAST3.isArrays(ast)) {
    ast.elements.forEach((p) => inspectDomain(p, ancestors));
    ast.rest.forEach((p) => inspectDomain(p, ancestors));
  }
  if (SchemaAST3.isUnion(ast)) {
    ast.types.forEach((p) => inspectDomain(p, ancestors));
  }
  if (SchemaAST3.isDeclaration(ast)) {
    ast.typeParameters.forEach((p) => inspectDomain(p, ancestors));
  }
  ast.encoding?.forEach((link) => inspectDomain(link.to, ancestors));
  ancestors.delete(ast);
};
var encrypted = (options) => {
  const { schema, codec: codec2 } = options;
  inspectDomain(schema.ast);
  inspectDomain(codec2.envelope.ast);
  const inspectEnvelope = (ast) => {
    if (ast.encoding !== void 0 || SchemaAST3.isDeclaration(ast)) {
      throw new InvalidEncryptedSchema({ reason: "invalid-envelope" });
    }
    if (SchemaAST3.isObjects(ast)) {
      if (ast.indexSignatures.length > 0) {
        throw new InvalidEncryptedSchema({ reason: "invalid-envelope" });
      }
      ast.propertySignatures.forEach((p) => inspectEnvelope(p.type));
    }
    if (SchemaAST3.isArrays(ast)) {
      if (ast.elements.length !== 0 || ast.rest.length !== 1) {
        throw new InvalidEncryptedSchema({ reason: "invalid-envelope" });
      }
      ast.rest.forEach(inspectEnvelope);
    }
    if (SchemaAST3.isUnion(ast)) {
      ast.types.forEach(inspectEnvelope);
    }
  };
  inspectEnvelope(codec2.envelope.ast);
  const envelopeAst = codec2.envelope.ast;
  if (!SchemaAST3.isObjects(envelopeAst) || envelopeAst.encoding !== void 0 || !envelopeAst.propertySignatures.some(
    (p) => p.name === "fingerprint" && p.type.context?.isOptional !== true
  )) {
    throw new InvalidEncryptedSchema({ reason: "invalid-envelope" });
  }
  const issue = () => new SchemaIssue.Forbidden({ message: "payload encryption failed" });
  const result = protectedPayload(codec2.envelope).pipe(
    Schema19.decodeTo(schema, {
      decode: SchemaGetter.transformEffect(
        (value) => codec2.open(value).pipe(Effect15.catchCause((cause) => Effect15.failCause(Cause5.map(cause, issue))))
      ),
      encode: SchemaGetter.transformEffect(
        (value) => codec2.seal(value).pipe(Effect15.catchCause((cause) => Effect15.failCause(Cause5.map(cause, issue))))
      )
    })
  );
  const link = result.ast.encoding?.at(-1);
  if (link === void 0) {
    throw new InvalidEncryptedSchema({ reason: "invalid-envelope" });
  }
  registerEncryption(link);
  return result;
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/PrivateDocument.ts
var DocumentKeys = class extends Context7.Service()("playground/DocumentKeys") {
};
var Document = Schema20.Struct({
  subject: Schema20.Literal("demo-customer"),
  tenant: Schema20.Literals(["demo-tenant-a", "demo-tenant-b"]),
  note: Schema20.String.pipe(Schema20.check(Schema20.isMaxLength(256)))
});
var Envelope = Schema20.Struct({
  nonce: Schema20.Array(
    Schema20.Int.pipe(Schema20.check(Schema20.isBetween({ minimum: 0, maximum: 255 })))
  ).pipe(Schema20.check(Schema20.isMinLength(12), Schema20.isMaxLength(12))),
  ciphertext: Schema20.Array(
    Schema20.Int.pipe(Schema20.check(Schema20.isBetween({ minimum: 0, maximum: 255 })))
  ).pipe(Schema20.check(Schema20.isMaxLength(2048))),
  fingerprint: Schema20.String.pipe(
    Schema20.check(Schema20.isMinLength(64), Schema20.isMaxLength(64))
  )
});
var aad = new TextEncoder().encode("playground-private-document-v1");
var canonical = (value) => new TextEncoder().encode(
  JSON.stringify({ subject: value.subject, tenant: value.tenant, note: value.note })
);
var hex = (value) => Array.from(new Uint8Array(value), (byte) => byte.toString(16).padStart(2, "0")).join("");
var cryptoOperation = (run2) => Effect16.tryPromise({ try: run2, catch: () => new JobEncryptionError() });
var keysLayer = Layer6.effect(
  DocumentKeys,
  cryptoOperation(async () => ({
    encryption: await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, [
      "encrypt",
      "decrypt"
    ]),
    fingerprint: await crypto.subtle.generateKey(
      { name: "HMAC", hash: "SHA-256", length: 256 },
      false,
      ["sign", "verify"]
    )
  }))
);
var codec = {
  envelope: Envelope,
  seal: (value) => Effect16.gen(function* () {
    const keys = yield* DocumentKeys;
    return yield* cryptoOperation(async () => {
      const bytes = canonical(value);
      const nonce = crypto.getRandomValues(new Uint8Array(12));
      const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: nonce, additionalData: aad },
        keys.encryption,
        bytes
      );
      const fingerprint = hex(await crypto.subtle.sign("HMAC", keys.fingerprint, bytes));
      return {
        nonce: Array.from(nonce),
        ciphertext: Array.from(new Uint8Array(ciphertext)),
        fingerprint
      };
    });
  }),
  open: (envelope) => Effect16.gen(function* () {
    const keys = yield* DocumentKeys;
    return yield* cryptoOperation(async () => {
      const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: new Uint8Array(envelope.nonce), additionalData: aad },
        keys.encryption,
        new Uint8Array(envelope.ciphertext)
      );
      const value = Schema20.decodeUnknownSync(Document)(
        JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(plaintext)),
        { onExcessProperty: "error" }
      );
      const expected = hex(
        await crypto.subtle.sign("HMAC", keys.fingerprint, canonical(value))
      );
      if (expected !== envelope.fingerprint) {
        throw new JobEncryptionError();
      }
      return value;
    });
  })
};
var EncryptedDocument = encrypted({ schema: Document, codec });

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/Definitions.ts
var Workload = Schema21.Literals([
  "welcome-email",
  "image-processing",
  "webhook-delivery",
  "private-data-export",
  "catalog-sync",
  "simulated-payment"
]);
var Behavior = Schema21.Literals([
  "success",
  "retry-then-success",
  "dead",
  "isolated",
  "accepted-response-lost"
]);
var Payload = Schema21.Struct({
  sandbox: SandboxRef,
  version: Schema21.Literal(1),
  seed: Schema21.Int.pipe(
    Schema21.check(Schema21.isBetween({ minimum: 0, maximum: 4294967295 }))
  ),
  sequence: Schema21.Int.pipe(Schema21.check(Schema21.isBetween({ minimum: 1, maximum: 10 }))),
  behavior: Behavior,
  actor: Schema21.Literal("demo-customer"),
  tenant: Schema21.Literals(["demo-tenant-a", "demo-tenant-b"]),
  order: Schema21.Literals(["demo-order-a", "demo-order-b"])
});
var ExportPayload = Schema21.Struct({
  ...Payload.fields,
  document: EncryptedDocument
});
var communications = make6("playground-communications");
var media = make6("playground-media");
var commerce = make6("playground-commerce");
var privateData = make6("playground-private");
var WelcomeEmail = make4({
  queue: communications,
  kind: "playground.welcome-email",
  payload: Payload
});
var ImageProcessing = make4({
  queue: media,
  kind: "playground.image-processing",
  payload: Payload
});
var WebhookDelivery = make4({
  queue: communications,
  kind: "playground.webhook-delivery",
  payload: Payload
});
var PrivateDataExport = make4({
  queue: privateData,
  kind: "playground.private-data-export",
  payload: ExportPayload
});
var CatalogSync = make4({
  queue: commerce,
  kind: "playground.catalog-sync",
  payload: Payload
});
var SimulatedPayment = make4({
  queue: commerce,
  kind: "playground.simulated-payment",
  payload: Payload
});
var Producer = make5({
  operation: "playground.synthetic",
  slots: [
    "welcome-email",
    "image-processing",
    "webhook-delivery",
    "private-data-export",
    "catalog-sync",
    "simulated-payment"
  ]
});
var definitions = [
  WelcomeEmail,
  ImageProcessing,
  WebhookDelivery,
  PrivateDataExport,
  CatalogSync,
  SimulatedPayment
];

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/Handlers.ts
var Handlers_exports = {};
__export(Handlers_exports, {
  codes: () => codes,
  execute: () => execute,
  executeExport: () => executeExport,
  layerNoDeps: () => layerNoDeps,
  toJobFailure: () => toJobFailure
});
import { Cause as Cause6, Effect as Effect18, Layer as Layer7, Match } from "effect";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/providers/FakeProvider.ts
import { Context as Context8, Data as Data15 } from "effect";
var RetryRejected = class extends Data15.TaggedError("RetryRejected") {
};
var TerminalRejected = class extends Data15.TaggedError("TerminalRejected") {
};
var InvariantViolation = class extends Data15.TaggedError("InvariantViolation") {
};
var ResponseLost = class extends Data15.TaggedError("ResponseLost") {
};
var PayloadConflict = class extends Data15.TaggedError("PayloadConflict") {
};
var LedgerFull = class extends Data15.TaggedError("LedgerFull") {
};
var FakeProvider = class extends Context8.Service()(
  "playground/FakeProvider"
) {
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/scenarios/Handlers.ts
var codes = define({
  rejected: "fake_provider_retry_rejected",
  terminal: "fake_provider_terminal_rejected",
  invariant: "fake_provider_invariant",
  lost: "fake_provider_response_lost",
  conflict: "fake_provider_payload_conflict",
  capacity: "fake_provider_ledger_full",
  codec: "scenario_codec_invalid"
});
var toJobFailure = Match.type().pipe(
  Match.when(
    { _tag: "RetryRejected" },
    () => JobFailures.Retry({ code: codes.rejected })
  ),
  Match.when(
    { _tag: "TerminalRejected" },
    () => JobFailures.Dead({ code: codes.terminal })
  ),
  Match.when(
    { _tag: "InvariantViolation" },
    () => JobFailures.Isolate({ code: codes.invariant })
  ),
  Match.when(
    { _tag: "ResponseLost" },
    () => JobFailures.OutcomeUnknown({ code: codes.lost })
  ),
  Match.when(
    { _tag: "PayloadConflict" },
    () => JobFailures.Isolate({ code: codes.conflict })
  ),
  Match.when({ _tag: "LedgerFull" }, () => JobFailures.Dead({ code: codes.capacity })),
  Match.exhaustive
);
var execute = (workload) => Effect18.fn("Playground.execute")(function* ({
  payload,
  context
}) {
  const provider = yield* FakeProvider;
  const encoded = yield* encodeJobPayload(Payload, payload).pipe(
    Effect18.catchCause(
      (cause) => Effect18.failCause(
        Cause6.map(cause, () => JobFailures.Isolate({ code: codes.codec }))
      )
    )
  );
  yield* provider.execute({
    sandbox: payload.sandbox,
    producer: context.producer,
    workload,
    behavior: payload.behavior,
    semanticProjection: encoded.semanticProjectionBytes
  }).pipe(
    Effect18.catchCause((cause) => Effect18.failCause(Cause6.map(cause, toJobFailure)))
  );
});
var executeExport = Effect18.fn("Playground.executeExport")(function* ({
  payload,
  context
}) {
  const provider = yield* FakeProvider;
  if (payload.document.subject !== payload.actor || payload.document.tenant !== payload.tenant) {
    return yield* Effect18.fail(JobFailures.Isolate({ code: codes.invariant }));
  }
  const encoded = yield* encodeJobPayload(ExportPayload, payload).pipe(
    Effect18.catchCause(
      (cause) => Effect18.failCause(Cause6.map(cause, () => JobFailures.Isolate({ code: codes.codec })))
    )
  );
  yield* provider.execute({
    sandbox: payload.sandbox,
    producer: context.producer,
    workload: "private-data-export",
    behavior: payload.behavior,
    semanticProjection: encoded.semanticProjectionBytes
  }).pipe(Effect18.catchCause((cause) => Effect18.failCause(Cause6.map(cause, toJobFailure))));
});
var layerNoDeps = Layer7.mergeAll(
  WelcomeEmail.handlerLayer(execute("welcome-email"), decodeJobPayload),
  ImageProcessing.handlerLayer(
    execute("image-processing"),
    decodeJobPayload
  ),
  WebhookDelivery.handlerLayer(
    execute("webhook-delivery"),
    decodeJobPayload
  ),
  PrivateDataExport.handlerLayer(executeExport, decodeJobPayload),
  CatalogSync.handlerLayer(execute("catalog-sync"), decodeJobPayload),
  SimulatedPayment.handlerLayer(
    execute("simulated-payment"),
    decodeJobPayload
  )
);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/execution/PostgreSqlProvider.ts
var PostgreSqlProvider_exports = {};
__export(PostgreSqlProvider_exports, {
  layerNoDeps: () => layerNoDeps2,
  make: () => make7
});
import { Cause as Cause7, Effect as Effect19, Layer as Layer8 } from "effect";
import { SqlClient } from "effect/sql/SqlClient";

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/persistence/authority/Schema.ts
var relations = (schema) => {
  if (!/^[a-z][a-z0-9_]{0,62}$/.test(schema)) {
    throw new Error("Invalid playground schema");
  }
  const table = (name2) => `"${schema}"."${name2}"`;
  return {
    sandboxes: table("sandboxes"),
    associations: table("associations"),
    receipts: table("command_receipts"),
    admission: table("command_admission"),
    audit: table("command_audit"),
    ledger: table("provider_ledger"),
    jobs: table("jobs")
  };
};

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/execution/PostgreSqlProvider.ts
var make7 = (schema) => Effect19.gen(function* () {
  const sql = yield* SqlClient;
  const t = relations(schema);
  return FakeProvider.of({
    execute: (command) => Effect19.gen(function* () {
      const projection = new Uint8Array(command.semanticProjection);
      const signature = yield* Effect19.tryPromise({
        try: async () => JSON.stringify([
          command.workload,
          command.behavior,
          Array.from(
            new Uint8Array(await crypto.subtle.digest("SHA-256", projection))
          )
        ]),
        catch: () => new InvariantViolation()
      });
      const outcome = yield* sql.withTransaction(
        Effect19.gen(function* () {
          const rows = yield* sql.unsafe(
            `SELECT *
          FROM ${t.sandboxes} WHERE sandbox_id=$1 FOR UPDATE`,
            [command.sandbox.sandboxId]
          );
          const sandbox = rows[0];
          const [clock] = yield* sql.unsafe(
            "SELECT floor(extract(epoch FROM clock_timestamp())*1000)::bigint AS now"
          );
          if (!sandbox || Number(sandbox.generation) !== command.sandbox.generation || Number(sandbox.expires_at) <= Number(clock.now)) {
            return new InvariantViolation();
          }
          const jobs = yield* sql.unsafe(
            `SELECT j.id FROM ${t.jobs} j JOIN ${t.associations} a ON a.job_id=j.id
          WHERE a.sandbox_id=$1 AND a.generation=$2 AND j.operation=$3 AND j.operation_id=$4 AND j.slot=$5 AND j.kind=$6`,
            [
              command.sandbox.sandboxId,
              command.sandbox.generation,
              command.producer.operation,
              command.producer.operationId,
              command.producer.slot,
              `playground.${command.workload}`
            ]
          );
          const job = jobs[0];
          if (!job) {
            return new InvariantViolation();
          }
          const existing = (yield* sql.unsafe(
            `SELECT * FROM ${t.ledger} WHERE job_id=$1`,
            [job.id]
          ))[0];
          if (existing && existing.signature !== signature) {
            return new PayloadConflict();
          }
          if (!existing) {
            const size = (yield* sql.unsafe(
              `SELECT count(*)::int AS n FROM ${t.ledger} WHERE sandbox_id=$1`,
              [command.sandbox.sandboxId]
            ))[0].n;
            if (size >= 100) {
              return new LedgerFull();
            }
          }
          const invocations = Math.min(
            Number(existing?.invocations ?? 0) + 1,
            1e6
          );
          const alreadyAccepted = existing?.accepted === true;
          const accepted = alreadyAccepted || command.behavior !== "dead" && command.behavior !== "isolated" && !(command.behavior === "retry-then-success" && invocations === 1);
          yield* sql.unsafe(
            `INSERT INTO ${t.ledger} VALUES ($1,$2,$3,$4,$5,$6)
          ON CONFLICT (sandbox_id,generation,job_id) DO UPDATE SET accepted=EXCLUDED.accepted,invocations=EXCLUDED.invocations`,
            [
              command.sandbox.sandboxId,
              command.sandbox.generation,
              job.id,
              signature,
              accepted,
              invocations
            ]
          );
          if (alreadyAccepted) {
            return void 0;
          }
          switch (command.behavior) {
            case "success":
              return void 0;
            case "retry-then-success":
              return invocations === 1 ? new RetryRejected() : void 0;
            case "dead":
              return new TerminalRejected();
            case "isolated":
              return new InvariantViolation();
            case "accepted-response-lost":
              return new ResponseLost();
          }
        })
      ).pipe(
        Effect19.catchCause(
          (cause) => Effect19.failCause(Cause7.map(cause, () => new ResponseLost()))
        )
      );
      if (outcome) {
        return yield* Effect19.fail(outcome);
      }
    }),
    // Mock observation DTO has source="mock"; a durable ledger must not impersonate it.
    inspect: () => Effect19.succeed(void 0)
  });
});
var layerNoDeps2 = (schema) => Layer8.effect(FakeProvider, make7(schema));

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/cloudflare/WakeCycle.ts
import { Clock as Clock2, Context as Context9, Effect as Effect20, Schema as Schema22 } from "effect";
var Delay = Schema22.Int.pipe(
  Schema22.check(Schema22.isBetween({ minimum: 0, maximum: 36e5 }))
);
var WakeSnapshot = Schema22.Struct({
  expiresInMillis: Delay,
  dueInMillis: Schema22.NullOr(Delay),
  recoveryInMillis: Schema22.NullOr(Delay)
});
var WakeUnavailable = class extends Schema22.TaggedError()(
  "WakeUnavailable",
  {}
) {
};
var WakeSchedule = class extends Context9.Service()("playground/cloudflare/WakeSchedule") {
};
var WakeAlarm = class extends Context9.Service()("playground/cloudflare/WakeAlarm") {
};
var limits2 = Object.freeze({
  cycleMillis: 5e3,
  backlogMillis: 100,
  backoffMillis: 1e3,
  repairMillis: 3e4,
  claimLimit: 10,
  recoveryLimit: 10,
  concurrency: 2
});

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/execution/Executor.ts
var limits3 = Object.freeze({
  cycleMillis: 5e3,
  generationMillis: 5e3,
  repairMillis: 5e3,
  claimLimit: 10,
  recoveryLimit: 10,
  concurrency: 2
});
var queueNames = [
  "playground-communications",
  "playground-media",
  "playground-commerce",
  "playground-private"
];
var ExecutionHints = class extends Context10.Service()("playground/ExecutionHints") {
};
var ExecutionDeadline = class extends Schema23.TaggedError()(
  "ExecutionDeadline",
  {}
) {
};
var consumers = Effect21.forEach(
  queueNames,
  (name2) => make(
    definitions.find((definition) => definition.queue.name === name2).queue,
    {
      localConcurrency: limits3.concurrency,
      claimLimitPerRun: limits3.claimLimit,
      recoveryLimitPerRun: limits3.recoveryLimit
    }
  )
);
var workerLayerNoDeps = (schema) => Layer9.unwrap(
  Effect21.gen(function* () {
    const backend = yield* PostgreSqlJobs;
    return layer2(backend.store, {
      catalog: definitions,
      operationResponseBudgetMillis: 500
    }).pipe(
      Layer9.provide(layerNoDeps),
      Layer9.provide(layer),
      Layer9.provide(layerNoDeps2(schema))
    );
  })
);
var snapshot = (schema, queue) => Effect21.gen(function* () {
  const sql = yield* SqlClient2;
  const t = relations(schema);
  const [row] = yield* sql.unsafe(
    `WITH t AS MATERIALIZED (SELECT floor(extract(epoch FROM clock_timestamp())*1000)::bigint AS now)
    SELECT t.now,
      (SELECT max(LEAST(expires_at,viewer_until)) FROM ${t.sandboxes} WHERE expires_at>t.now AND viewer_until>t.now) AS active_until,
      (SELECT min(j.available_at) FROM ${t.jobs} j JOIN ${t.associations} a ON a.job_id=j.id JOIN ${t.sandboxes} s ON s.sandbox_id=a.sandbox_id
        WHERE j.queue=$1 AND j.state IN ('Pending','RetryScheduled') AND a.generation=s.generation AND s.expires_at>t.now AND s.viewer_until>t.now) AS due,
      (SELECT min(lease_expires_at) FROM ${t.jobs} WHERE queue=$1 AND state='Active') AS recovery,
      (SELECT min(next_generation_at) FROM ${t.sandboxes} WHERE expires_at>t.now AND viewer_until>t.now AND retained_jobs<100) AS generate FROM t`,
    [queue]
  );
  const now = Number(row.now);
  return {
    activeMillis: row.active_until === null ? 0 : Math.max(0, Number(row.active_until) - now),
    nextMillis: Math.max(
      0,
      Math.min(
        limits3.repairMillis,
        ...[row.due, row.recovery, row.generate].filter((n) => n !== null).map((n) => Number(n) - now)
      )
    )
  };
});
var generate = (schema) => Effect21.gen(function* () {
  const sql = yield* SqlClient2;
  const persistence = yield* CommandPersistence;
  const t = relations(schema);
  const rows = yield* sql.unsafe(`SELECT *,floor(extract(epoch FROM clock_timestamp())*1000)::bigint AS now FROM ${t.sandboxes}
    WHERE expires_at>floor(extract(epoch FROM clock_timestamp())*1000)::bigint
      AND viewer_until>floor(extract(epoch FROM clock_timestamp())*1000)::bigint
      AND next_generation_at<=floor(extract(epoch FROM clock_timestamp())*1000)::bigint AND retained_jobs<100 ORDER BY sandbox_id LIMIT 1`);
  if (!rows[0]) {
    return;
  }
  const row = rows[0];
  const sandbox = yield* Schema23.decodeUnknownEffect(SandboxView)({
    ref: { sandboxId: row.sandbox_id, generation: Number(row.generation) },
    expiresAt: Number(row.expires_at),
    capabilities: {
      runScenario: true,
      resetSandbox: true,
      retryJob: false,
      redriveJob: false,
      cancelJob: false
    }
  });
  const result = yield* persistence.run(
    { sandbox },
    {
      sandbox: sandbox.ref,
      requestId: `auto-${String(row.next_generation_at)}`,
      scenario: "success",
      count: 1
    }
  );
  yield* sql.unsafe(
    `UPDATE ${t.sandboxes} SET next_generation_at=GREATEST(next_generation_at+5000,$3::bigint+5000)
    WHERE sandbox_id=$1 AND generation=$2 AND next_generation_at=$4 AND viewer_until>$3::bigint AND expires_at>$3::bigint`,
    [sandbox.ref.sandboxId, sandbox.ref.generation, row.now, row.next_generation_at]
  );
  return result;
});
var run = (schema, queue) => Effect21.gen(function* () {
  const alarm = yield* WakeAlarm;
  const hints = yield* ExecutionHints;
  const before = yield* snapshot(schema, queue);
  if (before.activeMillis === 0) {
    yield* alarm.clear;
    return { _tag: "Retired" };
  }
  const now = yield* Clock3.currentTimeMillis;
  yield* alarm.set(now + Math.min(before.activeMillis, limits3.repairMillis));
  if (queue === "playground-communications") {
    yield* generate(schema).pipe(
      Effect21.catchTag(
        "PlaygroundError",
        (error) => ["sandbox-expired", "stale-generation", "limit-reached"].includes(error.code) ? Effect21.void : Effect21.fail(error)
      )
    );
  }
  const plans = yield* consumers;
  const consumer = plans.find((plan) => plan.queue.name === queue);
  const result = yield* drain(consumer);
  yield* hints.reconcile;
  const after = yield* snapshot(schema, queue);
  if (after.activeMillis === 0) {
    yield* alarm.clear;
    return { _tag: "Retired" };
  }
  const at = yield* Clock3.currentTimeMillis;
  yield* alarm.set(
    at + Math.max(
      100,
      Math.min(
        after.activeMillis,
        result._tag === "MoreWork" ? 100 : result._tag === "Backoff" ? 1e3 : after.nextMillis,
        limits3.repairMillis
      )
    )
  );
  return result;
}).pipe(
  Effect21.timeoutOrElse({
    duration: limits3.cycleMillis,
    orElse: () => Effect21.fail(new ExecutionDeadline())
  })
);

// ../../../home/pc/multica_workspaces/upventure-43a8c02fcc9d/upve-1870-9362bac37f69/worktree/apps/playground-worker/src/persistence/authority/PostgreSqlAuthority.ts
var PostgreSqlAuthority_exports = {};
__export(PostgreSqlAuthority_exports, {
  authorityLayerNoDeps: () => authorityLayerNoDeps,
  make: () => make8,
  transactionsLayerNoDeps: () => transactionsLayerNoDeps,
  viewerMillis: () => viewerMillis
});
import { Cause as Cause8, Effect as Effect22, Layer as Layer10, Option, Redacted as Redacted2, Schema as Schema24 } from "effect";
import { SqlClient as SqlClient3 } from "effect/sql/SqlClient";
import { isSqlError } from "effect/sql/SqlError";
var viewerMillis = 15e3;
var dbTime = "floor(extract(epoch FROM clock_timestamp())*1000)::bigint";
var fail = (code) => new PlaygroundError({ code });
var controls = (effect) => effect.pipe(
  Effect22.catchCause(
    (cause) => Effect22.failCause(
      Cause8.fromReasons(
        cause.reasons.map((reason) => {
          if (Cause8.isFailReason(reason) && isSqlError(reason.error) || Cause8.isDieReason(reason) && isSqlError(reason.defect)) {
            return Cause8.makeFailReason(
              new CommandTransactionFailure({ commitKnowledge: "Unknown" })
            );
          }
          return reason;
        })
      )
    )
  )
);
var digest = (value) => Effect22.tryPromise({
  try: async () => Array.from(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))
    ),
    (byte) => byte.toString(16).padStart(2, "0")
  ).join(""),
  catch: () => fail("unavailable")
});
var view = (row) => Schema24.decodeUnknownEffect(SandboxView)(
  {
    ref: { sandboxId: row.sandbox_id, generation: Number(row.generation) },
    expiresAt: Number(row.expires_at),
    capabilities: {
      runScenario: true,
      resetSandbox: true,
      retryJob: false,
      redriveJob: false,
      cancelJob: false
    }
  },
  { onExcessProperty: "error" }
).pipe(Effect22.mapError(() => fail("unavailable")));
var make8 = (schema) => Effect22.gen(function* () {
  const sql = yield* SqlClient3;
  const t = relations(schema);
  const query = (text, values = []) => sql.unsafe(text, values).pipe(
    Effect22.mapError(
      () => new CommandTransactionFailure({ commitKnowledge: "Unknown" })
    )
  );
  const locked = (id) => Effect22.gen(function* () {
    const rows = yield* query(
      `SELECT * FROM ${t.sandboxes} WHERE sandbox_id=$1 FOR UPDATE`,
      [id]
    );
    const [clock] = yield* query(`SELECT ${dbTime} AS db_now`);
    return rows.map((row) => ({ ...row, db_now: clock.db_now }));
  });
  const guard = (rows, expected) => Effect22.gen(function* () {
    const row = rows[0];
    if (!row) {
      return yield* fail("not-found");
    }
    if (Number(row.expires_at) <= Number(row.db_now)) {
      return yield* fail("sandbox-expired");
    }
    if (expected && Number(row.generation) !== expected.generation) {
      return yield* fail("stale-generation");
    }
    return row;
  });
  const publicEffect = (effect) => effect.pipe(
    Effect22.mapError(
      (error) => error instanceof PlaygroundError ? error : fail("unavailable")
    )
  );
  const renew = (access) => sql.withTransaction(
    Effect22.gen(function* () {
      const row = yield* guard(
        yield* locked(access.sandbox.ref.sandboxId),
        access.sandbox.ref
      );
      yield* query(
        `UPDATE ${t.sandboxes} SET viewer_until=LEAST(expires_at,$2::bigint+$3::bigint) WHERE sandbox_id=$1`,
        [row.sandbox_id, row.db_now, viewerMillis]
      );
      return yield* view(row);
    })
  ).pipe(publicEffect);
  const authority = SandboxAuthority.of({
    issue: () => Effect22.gen(function* () {
      const credential = yield* Effect22.sync(
        () => Array.from(
          crypto.getRandomValues(new Uint8Array(32)),
          (byte) => byte.toString(16).padStart(2, "0")
        ).join("")
      );
      const hash = yield* digest(credential);
      const id = yield* Effect22.sync(() => crypto.randomUUID());
      const rows = yield* query(
        `INSERT INTO ${t.sandboxes}(sandbox_id,generation,expires_at,credential_hash,viewer_until,next_generation_at)
        VALUES ($1,1,${dbTime}+$3::bigint,$2,${dbTime}+$4::bigint,${dbTime}+5000) RETURNING *`,
        [id, hash, limits.sandboxLifetimeMillis, viewerMillis]
      );
      return { sandbox: yield* view(rows[0]), credential: Redacted2.make(credential) };
    }).pipe(publicEffect),
    authenticate: (credential) => Effect22.gen(function* () {
      if (!/^[0-9a-f]{64}$/.test(Redacted2.value(credential))) {
        return yield* fail("not-found");
      }
      const hash = yield* digest(Redacted2.value(credential));
      const row = yield* guard(
        yield* query(
          `SELECT *,${dbTime} AS db_now FROM ${t.sandboxes} WHERE credential_hash=$1`,
          [hash]
        )
      );
      return { sandbox: yield* view(row) };
    }).pipe(publicEffect),
    describe: renew
  });
  const receipt = (ref, requestId, operation) => query(
    `SELECT receipt FROM ${t.receipts} WHERE sandbox_id=$1 AND generation=$2 AND operation=$3 AND request_id=$4`,
    [ref.sandboxId, ref.generation, operation, requestId]
  ).pipe(
    Effect22.flatMap(
      (rows) => rows[0] ? Schema24.decodeUnknownEffect(StoredReceipt)(rows[0].receipt, {
        onExcessProperty: "error"
      }).pipe(Effect22.mapError(() => fail("unavailable"))) : Effect22.succeed(null)
    )
  );
  const transactions = CommandTransactions.of({
    owned: (access, request, operation, body) => Effect22.gen(function* () {
      if (Option.isSome(yield* Effect22.serviceOption(sql.transactionService))) {
        return yield* new CommandTransactionFailure({
          commitKnowledge: "NotCommitted"
        });
      }
      if (request.sandbox.sandboxId !== access.sandbox.ref.sandboxId) {
        return yield* fail("not-found");
      }
      const fresh = yield* controls(
        sql.withTransaction(
          Effect22.gen(function* () {
            yield* guard(yield* locked(request.sandbox.sandboxId));
            const prior = yield* query(
              `SELECT request_id FROM ${t.admission} WHERE sandbox_id=$1 AND generation=$2 AND operation=$3 AND request_id=$4`,
              [
                request.sandbox.sandboxId,
                request.sandbox.generation,
                operation,
                request.requestId
              ]
            );
            if (prior.length) {
              return false;
            }
            const [budget] = yield* query(
              `SELECT count(*)::int AS n FROM ${t.admission} WHERE sandbox_id=$1`,
              [request.sandbox.sandboxId]
            );
            if (Number(budget.n) >= 200) {
              return yield* fail("limit-reached");
            }
            const inserted = yield* query(
              `INSERT INTO ${t.admission} VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING RETURNING request_id`,
              [
                request.sandbox.sandboxId,
                request.sandbox.generation,
                operation,
                request.requestId
              ]
            );
            return inserted.length === 1;
          })
        )
      );
      return yield* controls(
        sql.withTransaction(
          Effect22.gen(function* () {
            const row = yield* guard(yield* locked(request.sandbox.sandboxId));
            if (request.requestId.startsWith("auto-") && Number(row.viewer_until) <= Number(row.db_now)) {
              return yield* fail("sandbox-expired");
            }
            const current = (yield* view(row)).ref;
            return yield* body({
              admission: fresh ? "Fresh" : "Unresolved",
              current,
              dbNow: Number(row.db_now),
              expiresAt: Number(row.expires_at),
              receipt: (req, op) => receipt(req.sandbox, req.requestId, op),
              reserve: (count) => Effect22.gen(function* () {
                if (!Number.isInteger(count) || count < 1 || count > 10) {
                  return yield* fail("limit-reached");
                }
                const reserved = yield* query(
                  `UPDATE ${t.sandboxes} SET retained_jobs=retained_jobs+$2::int
              WHERE sandbox_id=$1 AND retained_jobs+$2::int<=100 RETURNING sandbox_id`,
                  [current.sandboxId, count]
                );
                if (!reserved.length) {
                  return yield* fail("limit-reached");
                }
              }),
              associate: (jobId, job) => query(`INSERT INTO ${t.associations} VALUES ($1,$2,$3,$4::jsonb)`, [
                current.sandboxId,
                current.generation,
                jobId,
                JSON.stringify({
                  syntheticActor: job.payload.actor,
                  syntheticOrderId: job.payload.order
                })
              ]).pipe(Effect22.asVoid),
              advanceGeneration: (expected) => Effect22.gen(function* () {
                const updated = yield* query(
                  `UPDATE ${t.sandboxes} SET generation=generation+1, next_generation_at=${dbTime}+5000
              WHERE sandbox_id=$1 AND generation=$2 AND generation<9007199254740991 RETURNING *`,
                  [expected.sandboxId, expected.generation]
                );
                if (!updated.length) {
                  return yield* fail("stale-generation");
                }
                return (yield* view(updated[0])).ref;
              }),
              saveReceipt: (value) => query(`INSERT INTO ${t.receipts} VALUES ($1,$2,$3,$4,$5::jsonb)`, [
                request.sandbox.sandboxId,
                request.sandbox.generation,
                operation,
                request.requestId,
                JSON.stringify(value)
              ]).pipe(Effect22.asVoid),
              audit: (entry) => query(`INSERT INTO ${t.audit} VALUES ($1,$2,$3,$4,$5,${dbTime})`, [
                current.sandboxId,
                current.generation,
                entry.operation,
                entry.reason,
                entry.count
              ]).pipe(Effect22.asVoid)
            });
          })
        )
      );
    }),
    lookup: (access, request, operation) => controls(
      sql.withTransaction(
        Effect22.gen(function* () {
          if (request.sandbox.sandboxId !== access.sandbox.ref.sandboxId) {
            return yield* fail("not-found");
          }
          const row = yield* guard(yield* locked(request.sandbox.sandboxId));
          if (request.sandbox.generation > Number(row.generation)) {
            return yield* fail("stale-generation");
          }
          return yield* receipt(request.sandbox, request.requestId, operation);
        })
      )
    )
  });
  return { authority, transactions };
});
var authorityLayerNoDeps = (schema) => Layer10.effect(
  SandboxAuthority,
  make8(schema).pipe(Effect22.map((services) => services.authority))
);
var transactionsLayerNoDeps = (schema) => Layer10.effect(
  CommandTransactions,
  make8(schema).pipe(Effect22.map((services) => services.transactions))
);
export {
  PostgreSqlAuthority_exports as Authority,
  Executor_exports as Executor,
  FakeProvider,
  Handlers_exports as Handlers,
  JobWorker,
  JobWorkerUnavailable,
  PostgreSqlProvider_exports as Provider,
  WakeAlarm,
  WorkerCapability
};
