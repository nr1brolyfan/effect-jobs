// Qualification FFI: assertions share one packed program across Node/Bun/workerd.
import assert from "node:assert/strict"
import { Cause, Deferred, Duration, Effect, Exit, Fiber, Layer, Redacted } from "effect"
import { Schema } from "effect"
import { ApplicationRelations } from "@effect-jobs/playground-contracts/Jobs"
import * as Reactivity from "effect/reactivity/Reactivity"
import * as Pg from "@effect/sql-pg/PgClient"
import { SqlClient } from "effect/sql/SqlClient"
import * as Native from "effect-jobs/PostgreSqlNative"
import * as Backend from "effect-jobs/PostgreSqlJobs"
import { PostgreSqlApplication } from "effect-jobs/PostgreSqlTransaction"
import { JobEnqueue } from "effect-jobs/JobEnqueue"
import * as Policy from "effect-jobs/JobPolicy"
import * as Codec from "effect-jobs/JobPayloadCodec"
import * as Authority from "./dist/src/persistence/authority/PostgreSqlAuthority.js"
import * as Persistence from "./dist/src/persistence/commands/Persistence.js"
import {
  CommandPersistence,
  CommandTransactions,
  CommandTransactionFailure
} from "./dist/src/persistence/commands/Transactions.js"
import * as Provider from "./dist/src/execution/PostgreSqlProvider.js"
import * as Executor from "./dist/src/execution/Executor.js"
import * as Application from "./dist/src/execution/Application.js"
import * as Definitions from "./dist/src/scenarios/Definitions.js"
import * as Plan from "./dist/src/scenarios/Plan.js"
import * as Documents from "./dist/src/scenarios/PrivateDocument.js"
import { WakeAlarm } from "./dist/src/cloudflare/WakeCycle.js"

export const probe = (url, schema, alarm, checks = []) =>
  Effect.scoped(
    Effect.gen(function* () {
      const client = yield* Pg.make({
        url: Redacted.make(url),
        minConnections: 0,
        maxConnections: 6,
        prepare: false,
        connectTimeout: "2 seconds",
        idleTimeout: "1 second"
      })
      const adapter = Native.make({ client, operationTimeoutMillis: 2000 })
      const backend = yield* Backend.make({
        schema,
        operationResponseBudgetMillis: 500
      }).pipe(Effect.provideService(PostgreSqlApplication, adapter))
      yield* backend.ready
      const sql = (text, params = []) => client.unsafe(text, params)
      const services = yield* Authority.make(schema).pipe(
        Effect.provideService(SqlClient, client)
      )
      const command = yield* Persistence.make.pipe(
        Effect.provideService(CommandTransactions, services.transactions),
        Effect.provideService(JobEnqueue, backend.producer)
      )
      const provider = yield* Provider.make(schema).pipe(
        Effect.provideService(SqlClient, client)
      )
      const issue = () => services.authority.issue()
      const authenticate = (issued) => services.authority.authenticate(issued.credential)
      const a = yield* issue()
      const b = yield* issue()
      yield* sql(`UPDATE ${schema}.sandboxes SET next_generation_at=expires_at`)
      let access = yield* authenticate(a)
      const other = yield* authenticate(b)
      const current = () => access.sandbox.ref
      const run = (requestId, scenario = "success", count = 1) =>
        command.run(access, { sandbox: current(), requestId, scenario, count })
      const queryJob = (id) =>
        sql(`SELECT * FROM ${schema}.jobs WHERE id=$1`, [id]).pipe(
          Effect.map((rows) => rows[0])
        )
      const shortPolicy = Policy.make({
        leaseDuration: Duration.millis(1800),
        attemptTimeout: Duration.millis(200),
        retryDelay: Duration.millis(500),
        maxAttempts: 3
      })
      const produce = (id, behavior = "success", availableAt) =>
        backend.withTransaction(() =>
          Effect.gen(function* () {
            const [job] = yield* Plan.plan(
              { sandbox: current(), requestId: id, scenario: "success", count: 1 },
              current(),
              0,
              availableAt
            )
            const produced = yield* Plan.enqueue({
              ...job,
              policy: shortPolicy,
              payload: { ...job.payload, behavior }
            })
            yield* sql(
              `UPDATE ${schema}.sandboxes SET retained_jobs=retained_jobs+1 WHERE sandbox_id=$1`,
              [current().sandboxId]
            )
            yield* sql(
              `INSERT INTO ${schema}.associations VALUES ($1,$2,$3,'{}'::jsonb)`,
              [current().sandboxId, current().generation, produced.jobId]
            )
            return {
              jobId: produced.jobId,
              job: { ...job, payload: { ...job.payload, behavior } }
            }
          })
        )
      const providerCommand = (job) =>
        Codec.encodeJobPayload(Definitions.Payload, job.payload).pipe(
          Effect.map((encoded) => ({
            sandbox: job.payload.sandbox,
            producer: job.producer,
            workload: job.workload,
            behavior: job.payload.behavior,
            semanticProjection: encoded.semanticProjectionBytes
          }))
        )
      let hints = 0
      const workerLayer = Application.layerNoDeps(schema).pipe(
        Layer.provide(Layer.succeed(Backend.PostgreSqlJobs, backend))
      )
      const wake = (queue = "playground-communications") =>
        Executor.run(schema, queue).pipe(
          Effect.provide(workerLayer),
          Effect.provideService(CommandPersistence, command),
          Effect.provideService(SqlClient, client),
          Effect.provideService(WakeAlarm, alarm),
          Effect.provideService(Executor.ExecutionHints, {
            reconcile: Effect.sync(() => {
              hints++
            })
          })
        )

      assert.equal(
        (yield* Effect.flip(services.authority.authenticate(Redacted.make("invalid"))))
          .code,
        "not-found"
      )
      assert.equal(
        (yield* sql(
          `SELECT credential_hash FROM ${schema}.sandboxes WHERE sandbox_id=$1`,
          [current().sandboxId]
        ))[0].credential_hash === Redacted.value(a.credential),
        false
      )
      const foreign = yield* Effect.flip(
        command.run(other, {
          sandbox: current(),
          requestId: "foreign",
          scenario: "success",
          count: 1
        })
      )
      assert.equal(foreign.code, "invalid-request")
      checks.push("random credential hash custody; authenticated sandbox isolation")

      const nested = yield* Effect.exit(client.withTransaction(run("nested")))
      assert(Exit.isFailure(nested))
      assert.equal(
        (yield* sql(
          `SELECT count(*)::int AS n FROM ${schema}.command_admission WHERE request_id='nested'`
        ))[0].n,
        0
      )
      const initial = yield* run("dedup", "deduplication", 6)
      assert.equal(initial._tag, "Committed")
      for (const row of yield* sql(`SELECT relations FROM ${schema}.associations`)) {
        Schema.decodeUnknownSync(ApplicationRelations)(row.relations, {
          onExcessProperty: "error"
        })
      }
      const mixed = yield* Effect.exit(
        services.transactions.owned(
          access,
          { sandbox: current(), requestId: "mixed" },
          "Scenario",
          () =>
            Effect.failCause(
              Cause.fromReasons([
                Cause.makeFailReason(
                  new CommandTransactionFailure({ commitKnowledge: "Unknown" })
                ),
                Cause.makeDieReason(new Error("synthetic adapter defect"))
              ])
            )
        )
      )
      assert(
        Exit.isFailure(mixed) && Cause.hasFails(mixed.cause) && Cause.hasDies(mixed.cause)
      )
      checks.push(
        "application composition, strict relation DTOs and mixed transaction Cause retained"
      )
      assert.deepEqual(yield* run("dedup", "deduplication", 6), initial)
      assert.equal((yield* sql(`SELECT count(*)::int AS n FROM ${schema}.jobs`))[0].n, 6)
      const queues = yield* Executor.consumers
      assert.deepEqual(
        queues.map((q) => q.queue.name),
        Executor.queueNames
      )
      for (const queue of Executor.queueNames) {
        yield* wake(queue)
      }
      assert(
        (yield* sql(`SELECT state FROM ${schema}.jobs`)).every(
          (r) => r.state === "Completed"
        )
      )
      assert.equal(
        (yield* sql(
          `SELECT count(*)::int AS n FROM ${schema}.provider_ledger WHERE accepted=true`
        ))[0].n,
        6
      )
      assert.equal(hints, 4)
      checks.push(
        "actual four fixed consumers, six real handlers, private codec, durable completion and hints"
      )

      const retry = yield* produce("retry", "retry-then-success")
      yield* wake()
      assert.equal((yield* queryJob(retry.jobId)).state, "RetryScheduled")
      yield* wake()
      assert.equal((yield* queryJob(retry.jobId)).state, "RetryScheduled")
      yield* Effect.sleep("600 millis")
      yield* wake()
      assert.equal((yield* queryJob(retry.jobId)).state, "Completed")
      const now = Number(
        (yield* sql(
          "SELECT floor(extract(epoch FROM clock_timestamp())*1000)::bigint AS now"
        ))[0].now
      )
      const delayed = yield* produce("delay", "success", now + 700)
      yield* wake()
      assert.equal((yield* queryJob(delayed.jobId)).state, "Pending")
      yield* Effect.sleep("800 millis")
      yield* wake()
      assert.equal((yield* queryJob(delayed.jobId)).state, "Completed")
      checks.push("DB-time delayed and retry wake cycles with actual scenario consumers")

      const lost = yield* produce("lost", "accepted-response-lost")
      const pc = yield* providerCommand(lost.job)
      assert.equal((yield* Effect.flip(provider.execute(pc)))._tag, "ResponseLost")
      const raced = yield* Effect.all([provider.execute(pc), provider.execute(pc)], {
        concurrency: 2
      })
      assert.equal(raced.length, 2)
      const entry = (yield* sql(
        `SELECT * FROM ${schema}.provider_ledger WHERE job_id=$1`,
        [lost.jobId]
      ))[0]
      assert.equal(entry.accepted, true)
      assert.equal(entry.invocations, 3)
      yield* wake()
      assert.equal((yield* queryJob(lost.jobId)).state, "Completed")
      const conflict = yield* Effect.flip(
        provider.execute({ ...pc, semanticProjection: new Uint8Array([42]) })
      )
      assert.equal(conflict._tag, "PayloadConflict")
      checks.push(
        "response loss after durable acceptance; concurrent ledger retries cause one synthetic effect"
      )

      const unknownWorker = yield* produce("unknown-worker", "accepted-response-lost")
      yield* wake()
      assert.equal((yield* queryJob(unknownWorker.jobId)).state, "Active")
      yield* Effect.sleep("1900 millis")
      yield* wake()
      assert.equal((yield* queryJob(unknownWorker.jobId)).state, "Completed")
      const dead = yield* produce("dead-worker", "dead")
      const isolated = yield* produce("isolated-worker", "isolated")
      yield* wake()
      assert.equal((yield* queryJob(dead.jobId)).state, "Dead")
      assert.equal((yield* queryJob(isolated.jobId)).state, "Isolated")
      checks.push(
        "real OutcomeUnknown retains ownership until recovery; durable dead/isolated handlers"
      )
      const recovering = yield* produce("recover")
      const old = yield* backend.store.claim({
        queue: Definitions.WelcomeEmail.queue.name,
        supportedCatalog: [Definitions.WelcomeEmail.catalog],
        leaseToken: crypto.randomUUID()
      })
      assert.equal(old._tag, "Claimed")
      yield* Effect.sleep("1900 millis")
      yield* wake()
      assert.equal((yield* queryJob(recovering.jobId)).state, "Completed")
      const stale = yield* Effect.exit(
        backend.store.finalize({
          ownership: old.claim.ownership,
          before: old.claim.snapshot,
          finalization: { _tag: "Complete" }
        })
      )
      assert(Exit.isFailure(stale))
      checks.push("bounded actual expired-lease recovery and stale finalization fencing")

      const pending = yield* produce("old-pending")
      const late = yield* providerCommand(pending.job)
      const oldRef = current()
      const resets = yield* Effect.all(
        ["reset-a", "reset-b"].map((requestId) =>
          Effect.exit(command.reset(access, { sandbox: oldRef, requestId }))
        ),
        { concurrency: 2 }
      )
      assert.equal(resets.filter(Exit.isSuccess).length, 1)
      const reset = resets.find(Exit.isSuccess).value
      access = yield* authenticate(a)
      assert.equal(current().generation, oldRef.generation + 1)
      assert.equal((yield* queryJob(pending.jobId)).state, "Pending")
      assert.equal(
        (yield* Effect.flip(provider.execute(late)))._tag,
        "InvariantViolation"
      )
      assert.equal(
        (yield* sql(
          `SELECT count(*)::int AS n FROM ${schema}.provider_ledger WHERE job_id=$1`,
          [pending.jobId]
        ))[0].n,
        0
      )
      const receipt = yield* command.resetReceipt(access, {
        sandbox: oldRef,
        requestId: reset.requestId
      })
      assert.deepEqual(receipt, reset)
      assert.equal(
        (yield* Effect.flip(
          command.run(access, {
            sandbox: oldRef,
            requestId: "stale",
            scenario: "success",
            count: 1
          })
        )).code,
        "invalid-request"
      )
      checks.push(
        "concurrent reset CAS, exact old receipt, pending preserved, late provider write fenced"
      )

      // Zero viewers retires ALL fixed queues; renewing describe resumes the same generation.
      yield* sql(`UPDATE ${schema}.sandboxes SET viewer_until=0`)
      const paused = yield* produce("paused")
      assert.equal((yield* wake())._tag, "Retired")
      assert.equal((yield* queryJob(paused.jobId)).state, "Pending")
      yield* services.authority.describe(access)
      yield* wake()
      assert.equal((yield* queryJob(paused.jobId)).state, "Completed")
      yield* sql(
        `UPDATE ${schema}.sandboxes SET next_generation_at=0 WHERE sandbox_id=$1`,
        [current().sandboxId]
      )
      const beforeCount = (yield* sql(`SELECT count(*)::int AS n FROM ${schema}.jobs`))[0]
        .n
      yield* wake()
      assert.equal(
        (yield* sql(`SELECT count(*)::int AS n FROM ${schema}.jobs`))[0].n,
        beforeCount + 1
      )
      yield* wake()
      assert.equal(
        (yield* sql(`SELECT count(*)::int AS n FROM ${schema}.jobs`))[0].n,
        beforeCount + 1
      )
      checks.push(
        "unattended global retirement, describe reactivation, bounded due generation"
      )

      // Actual quota race near the app-owned retained cap; no lifecycle DML in executor.
      let retained = Number(
        (yield* sql(`SELECT retained_jobs FROM ${schema}.sandboxes WHERE sandbox_id=$1`, [
          current().sandboxId
        ]))[0].retained_jobs
      )
      while (retained < 99) {
        yield* run(`fill-${retained}`, "success", Math.min(10, 99 - retained))
        retained = Math.min(99, retained + 10)
      }
      const quota = yield* Effect.all(
        ["quota-a", "quota-b"].map((id) => Effect.exit(run(id))),
        { concurrency: 2 }
      )
      assert.equal(quota.filter(Exit.isSuccess).length, 1)
      assert.equal(
        (yield* sql(`SELECT retained_jobs FROM ${schema}.sandboxes WHERE sandbox_id=$1`, [
          current().sandboxId
        ]))[0].retained_jobs,
        100
      )
      const unknownRequest = { sandbox: current(), requestId: "unresolved" }
      yield* sql(`INSERT INTO ${schema}.command_admission VALUES ($1,$2,'Scenario',$3)`, [
        current().sandboxId,
        current().generation,
        unknownRequest.requestId
      ])
      const unknown = yield* run(unknownRequest.requestId)
      assert.equal(unknown._tag, "OutcomeUnknown")
      assert.equal(
        (yield* command.scenarioReceipt(access, unknownRequest))._tag,
        "OutcomeUnknown"
      )
      checks.push("atomic quota race; missing receipt never grants replay")
      yield* sql(
        `INSERT INTO ${schema}.command_admission SELECT $1,1,'Scenario','fixture-'||n FROM generate_series(1,200) n`,
        [other.sandbox.ref.sandboxId]
      )
      assert.equal(
        (yield* Effect.flip(
          command.reset(other, { sandbox: other.sandbox.ref, requestId: "over-budget" })
        )).code,
        "limit-reached"
      )
      checks.push(
        "bounded command admission journal prevents unbounded resets/receipt growth"
      )

      const entered = yield* Deferred.make()
      const fiber = yield* Effect.forkScoped(
        client.withTransaction(
          Effect.gen(function* () {
            yield* sql(
              `SELECT sandbox_id FROM ${schema}.sandboxes WHERE sandbox_id=$1 FOR UPDATE`,
              [current().sandboxId]
            )
            yield* Deferred.succeed(entered, undefined)
            yield* sql("SELECT pg_sleep(8)")
          })
        )
      )
      yield* Deferred.await(entered)
      yield* Fiber.interrupt(fiber)
      const exit = yield* Fiber.await(fiber)
      assert(Exit.isFailure(exit) && Cause.hasInterrupts(exit.cause))
      assert.equal(Number((yield* sql("SELECT 1 AS n"))[0].n), 1)
      yield* sql(`UPDATE ${schema}.sandboxes SET expires_at=0 WHERE sandbox_id=$1`, [
        current().sandboxId
      ])
      assert.equal(
        (yield* Effect.flip(services.authority.describe(access))).code,
        "sandbox-expired"
      )
      assert.equal(
        (yield* Effect.flip(services.authority.authenticate(a.credential))).code,
        "sandbox-expired"
      )
      checks.push("real SQL interruption and reusable scoped client; DB-time expiry")
      return { status: "PASS", checks, hosted: "NotTested", scheduledAlarm: "NotTested" }
    }).pipe(Effect.provide(Documents.keysLayer))
  ).pipe(Effect.provide(Reactivity.layer), Effect.timeout("50 seconds"))
