declare module "cloudflare:workers" {
  export class DurableObject {
    constructor(ctx: any, env: any)
  }
}
